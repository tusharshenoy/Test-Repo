#!/usr/bin/env python3
"""
test_03_dma_loopback.py — RF loopback test: DDS TX → RX DMA capture
Requires: TX1A → RX1A (direct SMA cable loopback)

Uses DDS to transmit a known CW tone, captures on RX via DMA,
and verifies the tone is received correctly (frequency + power).
This validates the AD9361 RF path + RX DMA independently of OFDM.
"""

import sys
import time
import numpy as np

try:
    import iio
except ImportError:
    print("[FAIL] pylibiio not installed. Run: pip3 install pylibiio")
    sys.exit(1)

# -------------------------------------------------------
# Configuration
# -------------------------------------------------------
SAMPLE_RATE  = 30720000      # 30.72 MSPS
CENTER_FREQ  = 2400000000    # 2.4 GHz
RF_BW        = 20000000      # 20 MHz
TX_ATTEN     = -10.0         # dB (TX output ~-3 dBm, safe below AD9361 +2.5 dBm max RX input)
RX_GAIN      = 60.0          # dB (high gain needed to detect weak OFDM signals)
DDS_TONE_HZ  = 1000000       # 1 MHz test tone
DDS_SCALE    = 0.5           # DDS amplitude scale
NUM_SAMPLES  = 16384         # samples per buffer
NUM_BUFFERS  = 10            # number of buffers to capture
SKIP_BUFFERS = 3             # skip initial transient

# RF Safety Note (direct SMA cable, no external attenuator):
#   TX at -10 dB → output ~-3 dBm
#   AD9361 max RX input: +2.5 dBm absolute (LNA damage threshold)
#   Margin: 5.5 dB → SAFE for direct cable loopback
#   RX gain 60 dB → DDS RMS ~155, OFDM detectable above noise

# Thresholds
MIN_RMS      = 20            # minimum RMS for signal present
FREQ_TOL_HZ  = 50000         # frequency match tolerance (50 kHz)
MIN_SNR_DB   = 15            # minimum SNR


def find_devices(ctx):
    """Find AD9361 IIO devices."""
    phy = rx_dev = tx_dev = None
    for dev in ctx.devices:
        if dev.name == "ad9361-phy":
            phy = dev
        elif dev.name == "cf-ad9361-lpc":
            rx_dev = dev
        elif dev.name == "cf-ad9361-dds-core-lpc":
            tx_dev = dev
    return phy, rx_dev, tx_dev


def main():
    print("============================================")
    print("  TEST 03: RF Loopback (DDS TX → RX DMA)")
    print("============================================")
    print("")
    print("[PREREQ] Connect: TX1A → RX1A (direct SMA cable, no attenuator needed)")
    print("")

    PASS = 0
    FAIL = 0

    # Connect to local IIO context
    try:
        ctx = iio.Context()
    except Exception as e:
        print(f"[FAIL] Cannot create IIO context: {e}")
        return 1

    phy, rx_dev, tx_dev = find_devices(ctx)
    if not all([phy, rx_dev, tx_dev]):
        print("[FAIL] Not all AD9361 IIO devices found!")
        return 1

    # -----------------------------------------------------------
    # 1. Configure AD9361
    # -----------------------------------------------------------
    print("[1] Configuring AD9361...")
    try:
        phy.find_channel("voltage0", is_output=False).attrs["sampling_frequency"].value = str(SAMPLE_RATE)
        phy.find_channel("altvoltage0", is_output=True).attrs["frequency"].value = str(CENTER_FREQ)
        phy.find_channel("altvoltage1", is_output=True).attrs["frequency"].value = str(CENTER_FREQ)
        phy.find_channel("voltage0", is_output=False).attrs["rf_bandwidth"].value = str(RF_BW)
        phy.find_channel("voltage0", is_output=True).attrs["rf_bandwidth"].value = str(RF_BW)
        phy.find_channel("voltage0", is_output=True).attrs["hardwaregain"].value = str(TX_ATTEN)
        phy.find_channel("voltage0", is_output=False).attrs["gain_control_mode"].value = "manual"
        phy.find_channel("voltage0", is_output=False).attrs["hardwaregain"].value = str(RX_GAIN)
        PASS += 1
        print(f"  [PASS] AD9361 configured")
        print(f"  Freq: {CENTER_FREQ/1e9} GHz, Rate: {SAMPLE_RATE/1e6} MSPS")
    except Exception as e:
        print(f"  [FAIL] Config error: {e}")
        return 1

    # -----------------------------------------------------------
    # 2. Configure DDS tone on TX
    # -----------------------------------------------------------
    print(f"\n[2] Setting up DDS tone at {DDS_TONE_HZ/1e6} MHz...")
    try:
        # TX1_I_F1 (altvoltage0): tone at DDS_TONE_HZ, 0 degrees
        ch = tx_dev.find_channel("altvoltage0", is_output=True)
        ch.attrs["frequency"].value = str(DDS_TONE_HZ)
        ch.attrs["scale"].value = str(DDS_SCALE)
        ch.attrs["phase"].value = "0"

        # TX1_I_F2 (altvoltage1): disabled
        ch = tx_dev.find_channel("altvoltage1", is_output=True)
        ch.attrs["scale"].value = "0"

        # TX1_Q_F1 (altvoltage2): tone at DDS_TONE_HZ, 90 degrees
        ch = tx_dev.find_channel("altvoltage2", is_output=True)
        ch.attrs["frequency"].value = str(DDS_TONE_HZ)
        ch.attrs["scale"].value = str(DDS_SCALE)
        ch.attrs["phase"].value = "90000"

        # TX1_Q_F2 (altvoltage3): disabled
        ch = tx_dev.find_channel("altvoltage3", is_output=True)
        ch.attrs["scale"].value = "0"

        PASS += 1
        print(f"  [PASS] DDS tone configured: {DDS_TONE_HZ/1e6} MHz, scale={DDS_SCALE}")
    except Exception as e:
        print(f"  [FAIL] DDS setup error: {e}")
        FAIL += 1
        return 1

    # Wait for DDS to stabilize
    time.sleep(0.5)

    # -----------------------------------------------------------
    # 3. Capture RX via DMA
    # -----------------------------------------------------------
    print(f"\n[3] Capturing {NUM_BUFFERS} RX buffers...")
    rx_i = rx_dev.find_channel("voltage0", is_output=False)
    rx_q = rx_dev.find_channel("voltage1", is_output=False)
    if not rx_i or not rx_q:
        print("  [FAIL] Cannot find RX I/Q channels")
        return 1
    rx_i.enabled = True
    rx_q.enabled = True

    rx_buf = iio.Buffer(rx_dev, NUM_SAMPLES, False)

    all_i = []
    all_q = []
    for buf_idx in range(NUM_BUFFERS):
        rx_buf.refill()
        raw = np.frombuffer(rx_buf.read(), dtype=np.int16)
        if buf_idx >= SKIP_BUFFERS:
            all_i.append(raw[0::2].astype(np.float64))
            all_q.append(raw[1::2].astype(np.float64))

    rx_i_data = np.concatenate(all_i)
    rx_q_data = np.concatenate(all_q)
    PASS += 1
    print(f"  [PASS] Captured {len(rx_i_data)} samples")

    # -----------------------------------------------------------
    # 4. Signal power analysis
    # -----------------------------------------------------------
    print("\n[4] Analyzing signal...")
    rms = np.sqrt(np.mean(rx_i_data**2 + rx_q_data**2))
    power_db = 10 * np.log10(np.mean(rx_i_data**2 + rx_q_data**2) + 1e-10)
    print(f"  RX RMS: {rms:.1f}")
    print(f"  RX Power: {power_db:.1f} dB")
    print(f"  I: mean={np.mean(rx_i_data):.1f}, std={np.std(rx_i_data):.1f}")
    print(f"  Q: mean={np.mean(rx_q_data):.1f}, std={np.std(rx_q_data):.1f}")

    # -----------------------------------------------------------
    # 5. FFT analysis
    # -----------------------------------------------------------
    print("\n[5] FFT analysis...")
    rx_complex = rx_i_data[:NUM_SAMPLES] + 1j * rx_q_data[:NUM_SAMPLES]
    window = np.hanning(NUM_SAMPLES)
    fft_vals = np.fft.fftshift(np.fft.fft(rx_complex * window))
    fft_db = 20 * np.log10(np.abs(fft_vals) + 1e-10)
    freqs = np.fft.fftshift(np.fft.fftfreq(NUM_SAMPLES, 1.0/SAMPLE_RATE))

    peak_idx = np.argmax(fft_db)
    peak_freq = freqs[peak_idx]
    peak_db = fft_db[peak_idx]
    noise_floor = np.median(fft_db)
    snr = peak_db - noise_floor

    print(f"  Peak frequency: {peak_freq/1e6:.3f} MHz")
    print(f"  Peak power: {peak_db:.1f} dB")
    print(f"  Noise floor: {noise_floor:.1f} dB")
    print(f"  SNR: {snr:.1f} dB")

    freq_error = abs(abs(peak_freq) - DDS_TONE_HZ)
    print(f"  Frequency error: {freq_error/1e3:.1f} kHz (tolerance: {FREQ_TOL_HZ/1e3} kHz)")

    # -----------------------------------------------------------
    # 6. Results
    # -----------------------------------------------------------
    print("\n============================================")

    # Check 1: Signal present
    if rms >= MIN_RMS:
        PASS += 1
        print(f"  [PASS] Signal present (RMS={rms:.1f} >= {MIN_RMS})")
    else:
        FAIL += 1
        print(f"  [FAIL] Signal too weak (RMS={rms:.1f} < {MIN_RMS})")
        print("         Check: SMA cable? Attenuator? Antenna ports?")

    # Check 2: Frequency correct
    if freq_error < FREQ_TOL_HZ:
        PASS += 1
        print(f"  [PASS] Frequency match ({peak_freq/1e6:.3f} MHz, error={freq_error/1e3:.1f} kHz)")
    else:
        FAIL += 1
        print(f"  [FAIL] Frequency mismatch (peak={peak_freq/1e6:.3f} MHz, expected={DDS_TONE_HZ/1e6:.1f} MHz)")

    # Check 3: SNR
    if snr >= MIN_SNR_DB:
        PASS += 1
        print(f"  [PASS] SNR = {snr:.1f} dB (>= {MIN_SNR_DB} dB)")
    else:
        FAIL += 1
        print(f"  [FAIL] SNR = {snr:.1f} dB (< {MIN_SNR_DB} dB)")

    print(f"\n  TEST 03 RESULT: {PASS} passed, {FAIL} failed")
    status = "PASS" if FAIL == 0 else "FAIL"
    print(f"  STATUS: {status}")
    print("============================================")
    return 0 if FAIL == 0 else 1


if __name__ == "__main__":
    sys.exit(main())

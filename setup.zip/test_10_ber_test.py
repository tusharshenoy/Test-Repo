#!/usr/bin/env python3
"""
test_10_ber_test.py — OFDM Bit Error Rate (BER) Test
Requires: TX1A → RX1A (direct SMA cable loopback)
Requires: FPGA bitstream with OFDM RX DMA (axi_ofdm_rx_dma at 0x7C440000)

Tests the full OFDM TX→RX chain and measures BER:
  PS → DAC DMA → PS_PL_FIFO (64→16b) → TX_Top (HDLC) → OFDM_Tx
    → AD9361 DAC → RF → RX → AD9361 ADC → Prepare_Inputs
    → OFDM_Rx (demod + Viterbi) → dec_data_out
    → OFDM RX DMA (0x7C440000) → PS DDR

Compares transmitted payload with received decoded data to compute BER.
"""

import sys
import time
import struct
import subprocess
import numpy as np

try:
    import iio
except ImportError:
    print("[FAIL] pylibiio not installed. Run: pip3 install pylibiio")
    sys.exit(1)

# -------------------------------------------------------
# Configuration
# -------------------------------------------------------
SAMPLE_RATE  = 30720000      # 30.72 MSPS
CENTER_FREQ  = 2400000000    # 2.4 GHz
RF_BW        = 20000000      # 20 MHz
TX_ATTEN     = -10.0         # dB (TX output ~-3 dBm, safe for direct SMA loopback)
RX_GAIN      = 60.0          # dB (high gain for OFDM signal detection)

# DMA addresses
DAC_DMA_BASE     = 0x7C420000   # TX DAC DMA (existing)
OFDM_RX_DMA_BASE = 0x7C440000   # OFDM RX decoded data DMA (new)

# OFDM parameters (from RTL)
BLOCK_SIZE   = 2522          # TX_Top HDLC block size (bytes)
FRAME_COUNT  = 2             # TX_Top number of HDLC frames
FFT_SIZE     = 128           # OFDM FFT size
CP_LEN       = 32            # Cyclic prefix length

# DMA buffer
TX_SAMPLES   = 32768         # TX DMA buffer size (samples)
RX_SAMPLES   = 65536         # RX DMA buffer size for decoded data capture
NUM_TX_PUSH  = 5             # Number of TX buffer pushes
SETTLE_TIME  = 5.0           # Seconds to wait for OFDM chain processing

# BER thresholds
MAX_BER      = 1e-3          # Maximum acceptable BER for PASS
MIN_BITS     = 100           # Minimum received bits to consider valid

# AXI DMAC register offsets (ADI axi_dmac v4.x)
DMAC_REG_VERSION     = 0x000
DMAC_REG_IRQ_MASK    = 0x080
DMAC_REG_IRQ_PENDING = 0x084
DMAC_REG_IRQ_SOURCE  = 0x088
DMAC_REG_CTRL        = 0x400
DMAC_REG_XFER_ID     = 0x404
DMAC_REG_XFER_SUBMIT = 0x408
DMAC_REG_FLAGS        = 0x40C
DMAC_REG_DEST_ADDR   = 0x410
DMAC_REG_SRC_ADDR    = 0x414
DMAC_REG_X_LENGTH    = 0x418
DMAC_REG_Y_LENGTH    = 0x41C
DMAC_REG_DEST_STRIDE = 0x420
DMAC_REG_SRC_STRIDE  = 0x424
DMAC_REG_STATUS      = 0x428
DMAC_REG_CURRENT_DEST= 0x434
DMAC_REG_PARTIAL_LEN = 0x44C


def devmem_read(addr):
    """Read 32-bit register via devmem."""
    try:
        result = subprocess.run(
            ["devmem", f"0x{addr:08X}", "32"],
            capture_output=True, text=True, timeout=5
        )
        if result.returncode == 0:
            return int(result.stdout.strip(), 16)
    except Exception:
        pass
    return None


def devmem_write(addr, value):
    """Write 32-bit register via devmem."""
    try:
        result = subprocess.run(
            ["devmem", f"0x{addr:08X}", "32", f"0x{value:08X}"],
            capture_output=True, text=True, timeout=5
        )
        return result.returncode == 0
    except Exception:
        return False


def find_devices(ctx):
    """Find AD9361 IIO devices."""
    phy = rx_dev = tx_dev = None
    for dev in ctx.devices:
        if dev.name == "ad9361-phy":
            phy = dev
        elif dev.name == "cf-ad9361-lpc":
            rx_dev = dev
        elif dev.name == "cf-ad9361-dds-core-lpc":
            tx_dev = dev
    return phy, rx_dev, tx_dev


def configure_ad9361(phy):
    """Configure AD9361 for OFDM loopback."""
    phy.find_channel("voltage0", is_output=False).attrs["sampling_frequency"].value = str(SAMPLE_RATE)
    phy.find_channel("altvoltage0", is_output=True).attrs["frequency"].value = str(CENTER_FREQ)
    phy.find_channel("altvoltage1", is_output=True).attrs["frequency"].value = str(CENTER_FREQ)
    phy.find_channel("voltage0", is_output=False).attrs["rf_bandwidth"].value = str(RF_BW)
    phy.find_channel("voltage0", is_output=True).attrs["rf_bandwidth"].value = str(RF_BW)
    phy.find_channel("voltage0", is_output=True).attrs["hardwaregain"].value = str(TX_ATTEN)
    phy.find_channel("voltage0", is_output=False).attrs["gain_control_mode"].value = "manual"
    phy.find_channel("voltage0", is_output=False).attrs["hardwaregain"].value = str(RX_GAIN)


def disable_dds(tx_dev):
    """Disable all DDS tones (so only DMA data goes through TX)."""
    for ch_id in range(8):
        ch = tx_dev.find_channel(f"altvoltage{ch_id}", is_output=True)
        if ch:
            ch.attrs["scale"].value = "0"


def generate_tx_payload():
    """
    Generate known test payload for TX.

    The TX_Top module expects 16-bit words that get HDLC-framed.
    We generate a repeating known pattern that we can match on RX.
    """
    # Simple repeating pattern: 0x55AA alternating with 0x33CC
    # This gives a good mix of bit transitions for BER measurement
    payload = np.zeros(TX_SAMPLES * 2, dtype=np.int16)
    for i in range(0, len(payload), 4):
        payload[i]     = np.int16(0x55AA)   # I sample
        payload[i + 1] = np.int16(0x33CC)   # Q sample
        payload[i + 2] = np.int16(0xAA55)   # I sample
        payload[i + 3] = np.int16(0xCC33)   # Q sample

    return payload


def check_ofdm_rx_dma_present():
    """Verify the OFDM RX DMA exists at expected address."""
    version = devmem_read(OFDM_RX_DMA_BASE + DMAC_REG_VERSION)
    if version is None or version == 0:
        return False, 0
    return True, version


def start_ofdm_rx_dma_capture(dest_addr, num_bytes):
    """
    Start a DMA transfer to capture OFDM RX decoded data.

    This programs the axi_ofdm_rx_dma to write FIFO data into DDR.
    The DMA collects dec_data_out words as they arrive from the OFDM RX chain.
    """
    base = OFDM_RX_DMA_BASE

    # 1. Disable DMA first
    devmem_write(base + DMAC_REG_CTRL, 0x00)
    time.sleep(0.01)

    # 2. Enable DMA
    devmem_write(base + DMAC_REG_CTRL, 0x01)
    time.sleep(0.01)

    # 3. Clear interrupts
    devmem_write(base + DMAC_REG_IRQ_PENDING, 0x03)

    # 4. Set destination address (DDR buffer)
    devmem_write(base + DMAC_REG_DEST_ADDR, dest_addr)

    # 5. Set transfer length (num_bytes - 1, per AXI DMAC spec)
    devmem_write(base + DMAC_REG_X_LENGTH, num_bytes - 1)

    # 6. Set flags (no last, no partial reporting needed)
    devmem_write(base + DMAC_REG_FLAGS, 0x00)

    # 7. Submit transfer
    devmem_write(base + DMAC_REG_XFER_SUBMIT, 0x01)

    return True


def wait_ofdm_rx_dma_complete(timeout=10.0):
    """Wait for OFDM RX DMA transfer to complete."""
    base = OFDM_RX_DMA_BASE
    start = time.time()
    while time.time() - start < timeout:
        pending = devmem_read(base + DMAC_REG_IRQ_PENDING)
        if pending is not None and (pending & 0x01):
            # Transfer complete — clear interrupt
            devmem_write(base + DMAC_REG_IRQ_PENDING, 0x01)
            return True
        time.sleep(0.1)
    return False


def read_dma_capture(dest_addr, num_bytes):
    """
    Read captured DMA data from DDR.
    Uses /dev/mem to read the DDR buffer.
    """
    try:
        with open("/dev/mem", "rb") as f:
            f.seek(dest_addr)
            raw = f.read(num_bytes)
        return np.frombuffer(raw, dtype=np.int16)
    except PermissionError:
        print("  [WARN] Cannot read /dev/mem directly. Trying devmem word-by-word...")
        # Fallback: read word-by-word via devmem (slow but works)
        data = []
        for offset in range(0, min(num_bytes, 4096), 4):
            val = devmem_read(dest_addr + offset)
            if val is not None:
                data.append(val & 0xFFFF)
                data.append((val >> 16) & 0xFFFF)
        return np.array(data, dtype=np.int16)
    except Exception as e:
        print(f"  [ERROR] Failed to read capture buffer: {e}")
        return np.array([], dtype=np.int16)


def compute_ber(tx_bits, rx_bits):
    """Compute BER between TX and RX bit sequences."""
    if len(rx_bits) == 0 or len(tx_bits) == 0:
        return 1.0, 0

    # Align by finding best correlation offset
    min_len = min(len(tx_bits), len(rx_bits))
    if min_len < MIN_BITS:
        return 1.0, min_len

    # Try different offsets to find alignment
    best_ber = 1.0
    best_offset = 0
    check_len = min(min_len, 1024)  # Check first 1024 bits for alignment

    for offset in range(min(64, len(rx_bits) - check_len)):
        tx_segment = tx_bits[:check_len]
        rx_segment = rx_bits[offset:offset + check_len]
        errors = np.sum(tx_segment != rx_segment)
        ber = errors / check_len
        if ber < best_ber:
            best_ber = ber
            best_offset = offset

    # Compute BER with best alignment over full data
    full_len = min(len(tx_bits), len(rx_bits) - best_offset)
    tx_aligned = tx_bits[:full_len]
    rx_aligned = rx_bits[best_offset:best_offset + full_len]
    total_errors = np.sum(tx_aligned != rx_aligned)
    final_ber = total_errors / full_len

    return final_ber, full_len


def words_to_bits(data):
    """Convert 16-bit words to bit array."""
    bits = []
    for word in data:
        for bit_pos in range(16):
            bits.append((int(word) >> bit_pos) & 1)
    return np.array(bits, dtype=np.uint8)


def main():
    print("============================================")
    print("  TEST 10: OFDM Bit Error Rate (BER) Test")
    print("============================================")
    print("")
    print("[PREREQ] Connect: TX1A → RX1A (direct SMA cable)")
    print("[PREREQ] FPGA bitstream must include OFDM RX DMA at 0x7C440000")
    print("")

    PASS = 0
    FAIL = 0

    # -----------------------------------------------------------
    # 1. Verify OFDM RX DMA exists
    # -----------------------------------------------------------
    print("[1] Checking OFDM RX DMA at 0x7C440000...")
    dma_present, dma_version = check_ofdm_rx_dma_present()
    if dma_present:
        PASS += 1
        print(f"  [PASS] OFDM RX DMA found (version: 0x{dma_version:08X})")
    else:
        FAIL += 1
        print("  [FAIL] OFDM RX DMA not found at 0x7C440000!")
        print("         Make sure you have the updated bitstream with OFDM RX DMA.")
        print("         Build: Vivado → source add_ofdm_rx_dma.tcl → Generate Bitstream")
        return 1

    # -----------------------------------------------------------
    # 2. Connect to IIO and configure AD9361
    # -----------------------------------------------------------
    print("\n[2] Configuring AD9361...")
    try:
        ctx = iio.Context()
    except Exception as e:
        print(f"[FAIL] Cannot create IIO context: {e}")
        return 1

    phy, rx_dev, tx_dev = find_devices(ctx)
    if not all([phy, rx_dev, tx_dev]):
        print("[FAIL] Not all IIO devices found")
        return 1

    configure_ad9361(phy)
    PASS += 1
    print(f"  [PASS] AD9361 configured (TX={TX_ATTEN} dB, RX={RX_GAIN} dB)")

    # -----------------------------------------------------------
    # 3. Disable DDS (ensure only DMA data goes to TX)
    # -----------------------------------------------------------
    print("\n[3] Disabling DDS tones...")
    disable_dds(tx_dev)
    PASS += 1
    print("  [PASS] DDS disabled")

    # -----------------------------------------------------------
    # 4. Start OFDM RX DMA capture
    # -----------------------------------------------------------
    print("\n[4] Starting OFDM RX DMA capture...")
    # Use a DDR buffer address above Linux kernel space
    # 0x1F000000 = 496 MB offset (safe for 512 MB Zynq with kernel < 256 MB)
    RX_DDR_ADDR = 0x1F000000
    RX_BYTES = RX_SAMPLES * 2  # 16-bit words → 2 bytes each

    started = start_ofdm_rx_dma_capture(RX_DDR_ADDR, RX_BYTES)
    if started:
        print(f"  OFDM RX DMA started: dest=0x{RX_DDR_ADDR:08X}, size={RX_BYTES} bytes")
    else:
        print("  [FAIL] Could not start OFDM RX DMA")
        FAIL += 1
        return 1

    # -----------------------------------------------------------
    # 5. Push TX data via DAC DMA
    # -----------------------------------------------------------
    print(f"\n[5] Pushing {NUM_TX_PUSH} TX buffers via DAC DMA...")
    try:
        tx_i = tx_dev.find_channel("voltage0", is_output=True)
        tx_q = tx_dev.find_channel("voltage1", is_output=True)
        tx_i.enabled = True
        tx_q.enabled = True

        tx_buf = iio.Buffer(tx_dev, TX_SAMPLES, True)  # cyclic=True

        # Generate and push TX payload
        tx_payload = generate_tx_payload()
        tx_buf.write(bytearray(tx_payload.tobytes()))
        tx_buf.push()
        PASS += 1
        print(f"  [PASS] TX DMA buffer pushed (cyclic, {TX_SAMPLES} samples)")
    except Exception as e:
        print(f"  [FAIL] TX DMA error: {e}")
        FAIL += 1
        return 1

    # -----------------------------------------------------------
    # 6. Wait for OFDM processing
    # -----------------------------------------------------------
    print(f"\n[6] Waiting {SETTLE_TIME}s for OFDM TX→RX chain processing...")
    time.sleep(SETTLE_TIME)

    # Check TX DMA status
    dac_ctrl = devmem_read(DAC_DMA_BASE + 0x400)
    dac_stat = devmem_read(DAC_DMA_BASE + 0x428)
    print(f"  DAC DMA: CTRL=0x{dac_ctrl:08X}, STATUS=0x{dac_stat:08X}" if dac_ctrl else "  DAC DMA: status read failed")

    # Check OFDM RX DMA status
    rx_dma_ctrl = devmem_read(OFDM_RX_DMA_BASE + DMAC_REG_CTRL)
    rx_dma_stat = devmem_read(OFDM_RX_DMA_BASE + DMAC_REG_STATUS)
    rx_dma_pending = devmem_read(OFDM_RX_DMA_BASE + DMAC_REG_IRQ_PENDING)
    rx_dma_partial = devmem_read(OFDM_RX_DMA_BASE + DMAC_REG_PARTIAL_LEN)
    print(f"  OFDM RX DMA: CTRL=0x{rx_dma_ctrl:08X}, STATUS=0x{rx_dma_stat:08X}")
    if rx_dma_pending is not None:
        print(f"  IRQ_PENDING=0x{rx_dma_pending:08X}, PARTIAL_LEN=0x{rx_dma_partial:08X}" if rx_dma_partial else f"  IRQ_PENDING=0x{rx_dma_pending:08X}")

    # -----------------------------------------------------------
    # 7. Read captured decoded data
    # -----------------------------------------------------------
    print("\n[7] Reading OFDM RX decoded data from DDR...")

    # Check if transfer completed
    completed = wait_ofdm_rx_dma_complete(timeout=5.0)
    if completed:
        print("  DMA transfer completed")
    else:
        print("  DMA transfer did not complete (may have partial data)")
        # Read partial length
        partial = devmem_read(OFDM_RX_DMA_BASE + DMAC_REG_PARTIAL_LEN)
        if partial and partial > 0:
            print(f"  Partial transfer: {partial} bytes received")
            RX_BYTES = min(RX_BYTES, partial)

    rx_data = read_dma_capture(RX_DDR_ADDR, RX_BYTES)
    print(f"  Read {len(rx_data)} words from capture buffer")

    if len(rx_data) == 0:
        print("  [FAIL] No decoded data captured")
        FAIL += 1
        print("\n  The OFDM RX DMA received no data. Possible causes:")
        print("    1. dec_valid_out never asserts (OFDM_Rx not producing output)")
        print("    2. FIFO write interface not connected correctly")
        print("    3. DMA clock domain mismatch")
        print("  Debug: Add ILA probes on dec_valid_out and fifo_wr_en")
        return 1

    # -----------------------------------------------------------
    # 8. Analyze received data
    # -----------------------------------------------------------
    print("\n[8] Analyzing decoded data...")

    # Basic statistics
    nonzero = np.count_nonzero(rx_data)
    total = len(rx_data)
    rms = np.sqrt(np.mean(rx_data.astype(np.float64)**2))

    print(f"  Total words: {total}")
    print(f"  Non-zero words: {nonzero} ({100*nonzero/total:.1f}%)")
    print(f"  RMS: {rms:.1f}")
    print(f"  Min: {np.min(rx_data)}, Max: {np.max(rx_data)}")

    if nonzero == 0:
        print("  [FAIL] All received data is zero — OFDM RX produced no decoded output")
        FAIL += 1
        print("\n  The OFDM RX chain decoded to all zeros. Likely causes:")
        print("    1. Viterbi decoder not converging (weak signal)")
        print("    2. Synchronization failure (no preamble detected)")
        print("    3. Frequency offset exceeding OFDM_Rx correction range")
        return 1

    PASS += 1
    print(f"  [PASS] Decoded data received ({nonzero} non-zero words)")

    # -----------------------------------------------------------
    # 9. Compute BER
    # -----------------------------------------------------------
    print("\n[9] Computing Bit Error Rate...")

    # Convert TX payload to bit sequence (what we sent)
    # The TX_Top HDLC framing adds flags and CRC, so the decoded output
    # should match the original payload data (after HDLC de-framing)
    # We use the pattern portion of the TX payload
    tx_pattern = tx_payload[::2]  # I samples only (the data we sent)
    tx_bits = words_to_bits(tx_pattern[:1024])  # First 1024 words = 16384 bits

    # Convert RX decoded data to bits
    rx_bits = words_to_bits(rx_data[:2048])  # Extra range for alignment search

    # Compute BER with alignment search
    ber, num_bits = compute_ber(tx_bits, rx_bits)

    print(f"  TX bits compared: {len(tx_bits)}")
    print(f"  RX bits compared: {num_bits}")
    print(f"  BER: {ber:.2e}")

    if num_bits < MIN_BITS:
        print(f"  [WARN] Too few bits for reliable BER ({num_bits} < {MIN_BITS})")

    # -----------------------------------------------------------
    # 10. Save captures
    # -----------------------------------------------------------
    print("\n[10] Saving capture files...")

    # Save decoded data
    with open("ber_rx_decoded.bin", "wb") as f:
        f.write(rx_data.tobytes())
    print(f"  Saved: ber_rx_decoded.bin ({len(rx_data)} words)")

    # Save TX reference
    with open("ber_tx_reference.bin", "wb") as f:
        f.write(tx_payload.tobytes())
    print(f"  Saved: ber_tx_reference.bin ({len(tx_payload)} words)")

    # -----------------------------------------------------------
    # 11. Results
    # -----------------------------------------------------------
    print("\n============================================")
    print("  RESULTS SUMMARY:")
    print(f"  {'Metric':25s} {'Value':>15s} {'Status':>8s}")
    print(f"  {'─'*25} {'─'*15} {'─'*8}")
    print(f"  {'OFDM RX DMA Present':25s} {'Yes':>15s} {'PASS':>8s}")
    print(f"  {'Decoded Words Received':25s} {nonzero:>15d} {'PASS' if nonzero > 0 else 'FAIL':>8s}")
    print(f"  {'Bits Compared':25s} {num_bits:>15d} {'':>8s}")

    ber_str = f"{ber:.2e}"
    if ber <= MAX_BER and num_bits >= MIN_BITS:
        PASS += 1
        ber_status = "PASS"
        print(f"  {'BER':25s} {ber_str:>15s} {'PASS':>8s}")
        print(f"\n  [PASS] BER = {ber:.2e} (<= {MAX_BER:.0e} threshold)")
    elif num_bits < MIN_BITS:
        FAIL += 1
        ber_status = "FAIL"
        print(f"  {'BER':25s} {ber_str:>15s} {'FAIL':>8s}")
        print(f"\n  [FAIL] Insufficient data for BER measurement ({num_bits} < {MIN_BITS} bits)")
    else:
        FAIL += 1
        ber_status = "FAIL"
        print(f"  {'BER':25s} {ber_str:>15s} {'FAIL':>8s}")
        print(f"\n  [FAIL] BER = {ber:.2e} (exceeds {MAX_BER:.0e} threshold)")
        print("  Possible causes:")
        print("    - OFDM synchronization issues (timing/frequency offset)")
        print("    - Insufficient SNR (try reducing RX gain to avoid clipping)")
        print("    - HDLC framing mismatch between TX and RX")
        print("    - Viterbi decoder trellis depth insufficient")

    print(f"\n  TEST 10: {PASS} passed, {FAIL} failed")
    status = "PASS" if FAIL == 0 else "FAIL"
    print(f"  STATUS: {status}")
    print("============================================")
    return 0 if FAIL == 0 else 1


if __name__ == "__main__":
    sys.exit(main())

#!/bin/bash
# setup.sh — Install dependencies for OFDM/AD9361 testing on ZedBoard
# Run once after booting Linux

set -e

echo "============================================"
echo "  OFDM Test Suite — Dependency Setup"
echo "============================================"

FAIL=0

# Check if running on ARM (ZedBoard)
ARCH=$(uname -m)
echo "[INFO] Architecture: $ARCH"

# 1. Check for iio_info (libiio command-line tools)
echo ""
echo "[1/4] Checking iio-utils..."
if command -v iio_info &>/dev/null; then
    echo "  [OK] iio_info found: $(which iio_info)"
elif command -v iio_attr &>/dev/null; then
    echo "  [OK] iio_attr found (iio_info may not be available)"
else
    echo "  [MISSING] iio-utils not found. Installing..."
    if command -v apt-get &>/dev/null; then
        apt-get update && apt-get install -y libiio-utils
    elif command -v opkg &>/dev/null; then
        opkg update && opkg install libiio-utils
    else
        echo "  [WARN] Cannot auto-install. Please install libiio-utils manually."
        echo "         On PetaLinux: add libiio to rootfs config"
        FAIL=1
    fi
fi

# 2. Check for Python3
echo ""
echo "[2/4] Checking Python3..."
if command -v python3 &>/dev/null; then
    PY=$(python3 --version 2>&1)
    echo "  [OK] $PY"
else
    echo "  [MISSING] Python3 not found."
    echo "  Install: apt-get install python3 OR add to PetaLinux rootfs"
    FAIL=1
fi

# 3. Check for pylibiio (Python IIO bindings)
echo ""
echo "[3/4] Checking Python libiio bindings..."
if python3 -c "import iio; print(f'  [OK] pylibiio version: {iio.version}')" 2>/dev/null; then
    :
else
    echo "  [MISSING] pylibiio not found. Attempting install..."
    if command -v pip3 &>/dev/null; then
        pip3 install pylibiio 2>/dev/null && echo "  [OK] Installed pylibiio" || {
            echo "  [WARN] pip install failed. Try: pip3 install pylibiio"
            FAIL=1
        }
    else
        echo "  [WARN] pip3 not found. Install python3-pip first."
        FAIL=1
    fi
fi

# 4. Check for numpy
echo ""
echo "[4/4] Checking numpy..."
if python3 -c "import numpy; print(f'  [OK] numpy version: {numpy.__version__}')" 2>/dev/null; then
    :
else
    echo "  [MISSING] numpy not found. Attempting install..."
    if command -v pip3 &>/dev/null; then
        pip3 install numpy 2>/dev/null && echo "  [OK] Installed numpy" || {
            echo "  [WARN] pip install failed. numpy may need to be cross-compiled."
            echo "  Add python3-numpy to PetaLinux rootfs config."
            FAIL=1
        }
    else
        echo "  [WARN] pip3 not found."
        FAIL=1
    fi
fi

# 5. Quick IIO context check
echo ""
echo "[BONUS] Checking IIO context..."
if command -v iio_info &>/dev/null; then
    DEV_COUNT=$(iio_info 2>/dev/null | grep -c "iio:device" || true)
    if [ "$DEV_COUNT" -gt 0 ]; then
        echo "  [OK] Found $DEV_COUNT IIO device(s)"
    else
        echo "  [WARN] No IIO devices found. Is the FPGA bitstream loaded?"
    fi
elif [ -d /sys/bus/iio/devices ]; then
    DEV_COUNT=$(ls /sys/bus/iio/devices/ 2>/dev/null | grep -c "iio:device" || true)
    echo "  [INFO] Found $DEV_COUNT IIO device(s) in sysfs"
else
    echo "  [WARN] /sys/bus/iio/devices not found"
fi

echo ""
echo "============================================"
if [ $FAIL -eq 0 ]; then
    echo "  All dependencies OK!"
    echo "============================================"
    exit 0
else
    echo "  Some dependencies missing — see above"
    echo "============================================"
    exit 1
fi

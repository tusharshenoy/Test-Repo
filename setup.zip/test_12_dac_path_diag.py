#!/usr/bin/env python3
"""
test_12_dac_path_diag.py — DAC Data Path & DMA Comprehensive Diagnostic

Purpose: Determine exactly WHERE the OFDM TX chain breaks by:
  1. Reading ALL DAC DMA registers (version, status, transfer state)
  2. Reading DAC DMA registers BEFORE and AFTER IIO push to detect changes
  3. Checking if axi_ad9361 DAC is in DMA mode (dac_data_sel register)
  4. Testing ADC capture to detect any RF output
  5. Testing with multiple captures to detect intermittent OFDM frames

This test works with BOTH TX_BYPASS=0 (normal OFDM) and TX_BYPASS=1 (bypass tone).
When TX_BYPASS=1, expect a strong ~960 kHz tone.
When TX_BYPASS=0 (normal), expect OFDM wideband or nothing (if chain is stuck).

Register map reference (ADI axi_dmac):
  0x000: VERSION         0x00C: PERIPHERAL_ID
  0x010: SCRATCH         0x020: IRQ_MASK
  0x024: IRQ_PENDING     0x028: IRQ_SOURCE
  0x080: CTRL            0x084: TRANSFER_ID
  0x088: TRANSFER_SUBMIT
  0x400: FLAGS           0x404: DEST_ADDRESS
  0x408: SRC_ADDRESS     0x40C: X_LENGTH
  0x410: Y_LENGTH        0x414: DEST_STRIDE
  0x418: SRC_STRIDE      0x428: TRANSFER_DONE
  0x42C: ACTIVE_ID       0x434: STATUS
  0x438: CURRENT_DEST    0x43C: CURRENT_SRC
  0x448: PARTIAL_XFER    0x44C: PARTIAL_LENGTH

axi_ad9361 DAC register map (per channel):
  Base + 0x0400 = DAC chan 0 (I0)
  0x0418: REG_CHAN_CNTRL_7 — dac_data_sel (bits [3:0])
    0 = internal DDS tone
    2 = DMA data (what we need)
    9 = zero output
"""

import sys
import time
import subprocess
import numpy as np

try:
    import iio
except ImportError:
    print("[FAIL] pylibiio not installed")
    sys.exit(1)

# Config
SAMPLE_RATE  = 30720000
CENTER_FREQ  = 2400000000
RF_BW        = 20000000
TX_ATTEN     = -10.0
RX_GAIN      = 60.0
TX_SAMPLES   = 32768
RX_CAPTURE   = 16384

# Hardware addresses
DAC_DMA_BASE     = 0x7C420000
AXI_AD9361_BASE  = 0x79020000   # axi_ad9361 IP base address

# axi_ad9361 DAC channel register offsets
DAC_CHAN0_BASE   = AXI_AD9361_BASE + 0x0400  # DAC I0
DAC_CHAN1_BASE   = AXI_AD9361_BASE + 0x0440  # DAC Q0
DAC_CHAN2_BASE   = AXI_AD9361_BASE + 0x0480  # DAC I1
DAC_CHAN3_BASE   = AXI_AD9361_BASE + 0x04C0  # DAC Q1
DAC_DATA_SEL_OFF = 0x0018   # REG_CHAN_CNTRL_7 offset within channel


def devmem_read(addr):
    """Read a 32-bit register via devmem"""
    try:
        r = subprocess.run(["devmem", f"0x{addr:08X}", "32"],
                           capture_output=True, text=True, timeout=5)
        if r.returncode == 0:
            return int(r.stdout.strip(), 16)
    except Exception:
        pass
    return None


def read_dma_regs(base, label=""):
    """Read all important DMA registers and return as dict"""
    regs = {}
    reg_map = {
        'VERSION':     0x000,
        'PERIPH_ID':   0x00C,
        'SCRATCH':     0x010,
        'IRQ_MASK':    0x020,
        'IRQ_PENDING': 0x024,
        'IRQ_SOURCE':  0x028,
        'CTRL':        0x080,
        'XFER_ID':     0x084,
        'XFER_SUBMIT': 0x088,
        'FLAGS':       0x400,
        'DEST_ADDR':   0x404,
        'SRC_ADDR':    0x408,
        'X_LENGTH':    0x40C,
        'Y_LENGTH':    0x410,
        'DEST_STRIDE': 0x414,
        'SRC_STRIDE':  0x418,
        'XFER_DONE':   0x428,
        'ACTIVE_ID':   0x42C,
        'STATUS':      0x434,
        'CUR_DEST':    0x438,
        'CUR_SRC':     0x43C,
        'PARTIAL_XFER':  0x448,
        'PARTIAL_LEN':   0x44C,
    }
    for name, offset in reg_map.items():
        val = devmem_read(base + offset)
        regs[name] = val
    return regs


def print_dma_regs(regs, label=""):
    """Pretty-print DMA registers"""
    if label:
        print(f"  === {label} ===")
    for name, val in regs.items():
        if val is not None:
            print(f"    {name:15s}: 0x{val:08X}")
        else:
            print(f"    {name:15s}: READ FAILED")


def main():
    print("=" * 65)
    print("  DAC Data Path & DMA Comprehensive Diagnostic")
    print("=" * 65)

    ctx = iio.Context()
    phy = rx_dev = tx_dev = None
    for dev in ctx.devices:
        if dev.name == "ad9361-phy":
            phy = dev
        elif dev.name == "cf-ad9361-lpc":
            rx_dev = dev
        elif dev.name == "cf-ad9361-dds-core-lpc":
            tx_dev = dev

    if not all([phy, rx_dev, tx_dev]):
        print("[FAIL] IIO devices not found")
        return

    # ============================================================
    # STAGE 1: Read DAC DMA registers BEFORE any TX activity
    # ============================================================
    print("\n--- Stage 1: DAC DMA state BEFORE TX ---")
    regs_before = read_dma_regs(DAC_DMA_BASE)
    print_dma_regs(regs_before, "DAC DMA (0x7C420000) - Before TX")

    ver = regs_before.get('VERSION')
    if ver is None or ver == 0:
        print("  [FAIL] Cannot read DAC DMA - wrong address or not present")
        return
    print(f"  DMA version: {(ver>>16)&0xFF}.{(ver>>8)&0xFF}.{ver&0xFF}")

    ctrl = regs_before.get('CTRL')
    if ctrl is not None:
        print(f"  DMA enabled: {'YES' if ctrl & 1 else 'NO'}")
        print(f"  DMA paused:  {'YES' if ctrl & 2 else 'NO'}")

    # ============================================================
    # STAGE 2: Check axi_ad9361 DAC data_sel registers
    # ============================================================
    print("\n--- Stage 2: axi_ad9361 DAC data_sel registers ---")
    data_sel_names = {0: "DDS_tone", 1: "SED_pattern", 2: "DMA_data",
                      8: "PN7", 9: "zero_output", 10: "PN15",
                      11: "PRBS_seq", 12: "input_sel"}

    for i, (name, base) in enumerate([
        ("I0", DAC_CHAN0_BASE), ("Q0", DAC_CHAN1_BASE),
        ("I1", DAC_CHAN2_BASE), ("Q1", DAC_CHAN3_BASE)
    ]):
        val = devmem_read(base + DAC_DATA_SEL_OFF)
        if val is not None:
            sel = val & 0xF
            sel_name = data_sel_names.get(sel, f"unknown({sel})")
            print(f"  DAC {name} data_sel: {sel} ({sel_name})")
        else:
            print(f"  DAC {name} data_sel: READ FAILED")

    # ============================================================
    # STAGE 3: Configure AD9361 and start TX
    # ============================================================
    print("\n--- Stage 3: Configure AD9361 and start TX ---")
    phy.find_channel("voltage0", False).attrs["sampling_frequency"].value = str(SAMPLE_RATE)
    phy.find_channel("altvoltage0", True).attrs["frequency"].value = str(CENTER_FREQ)
    phy.find_channel("altvoltage1", True).attrs["frequency"].value = str(CENTER_FREQ)
    phy.find_channel("voltage0", False).attrs["rf_bandwidth"].value = str(RF_BW)
    phy.find_channel("voltage0", True).attrs["rf_bandwidth"].value = str(RF_BW)
    phy.find_channel("voltage0", True).attrs["hardwaregain"].value = str(TX_ATTEN)
    phy.find_channel("voltage0", False).attrs["gain_control_mode"].value = "manual"
    phy.find_channel("voltage0", False).attrs["hardwaregain"].value = str(RX_GAIN)
    print("  AD9361 configured")

    # Disable DDS
    for ch_id in range(8):
        ch = tx_dev.find_channel(f"altvoltage{ch_id}", True)
        if ch:
            ch.attrs["scale"].value = "0"
    print("  DDS disabled")

    # ============================================================
    # STAGE 4: Capture ADC baseline (no TX DMA)
    # ============================================================
    print("\n--- Stage 4: ADC baseline (no DMA push yet) ---")
    rx_i = rx_dev.find_channel("voltage0", False)
    rx_q = rx_dev.find_channel("voltage1", False)
    rx_i.enabled = True
    rx_q.enabled = True

    rx_buf = iio.Buffer(rx_dev, RX_CAPTURE, False)
    for _ in range(3):
        rx_buf.refill()
    rx_buf.refill()
    raw = rx_buf.read()
    data = np.frombuffer(raw, dtype=np.int16)
    I_base = data[0::2].astype(np.float64)
    Q_base = data[1::2].astype(np.float64)
    rms_base = np.sqrt(np.mean(I_base**2 + Q_base**2))
    print(f"  Baseline RMS: {rms_base:.1f}")
    del rx_buf

    # ============================================================
    # STAGE 5: Push IIO TX buffer and check DMA state changes
    # ============================================================
    print("\n--- Stage 5: Push IIO TX buffer ---")

    # Read DAC DMA state RIGHT BEFORE push
    regs_pre_push = read_dma_regs(DAC_DMA_BASE)

    tx_i_ch = tx_dev.find_channel("voltage0", True)
    tx_q_ch = tx_dev.find_channel("voltage1", True)
    tx_i_ch.enabled = True
    tx_q_ch.enabled = True

    tx_buf = iio.Buffer(tx_dev, TX_SAMPLES, True)  # cyclic

    # Generate test payload (alternating pattern for easy detection)
    payload = np.zeros(TX_SAMPLES * 2, dtype=np.int16)
    for i in range(0, len(payload), 2):
        val = np.int16((i // 2) % 256)
        payload[i] = val        # I
        payload[i + 1] = val    # Q

    tx_buf.write(bytearray(payload.tobytes()))
    tx_buf.push()
    print("  TX buffer pushed (cyclic)")

    # Small delay for DMA to start
    time.sleep(0.5)

    # Read DAC DMA state RIGHT AFTER push
    regs_post_push = read_dma_regs(DAC_DMA_BASE)

    # Check data_sel after push
    print("\n  --- DAC data_sel AFTER IIO push ---")
    for i, (name, base) in enumerate([
        ("I0", DAC_CHAN0_BASE), ("Q0", DAC_CHAN1_BASE)
    ]):
        val = devmem_read(base + DAC_DATA_SEL_OFF)
        if val is not None:
            sel = val & 0xF
            sel_name = data_sel_names.get(sel, f"unknown({sel})")
            print(f"    DAC {name} data_sel: {sel} ({sel_name})")
            if sel != 2:
                print(f"    [WARN] Expected DMA_data (2), got {sel_name}")

    # Compare registers
    print("\n  --- DAC DMA register changes ---")
    changed = False
    for key in regs_pre_push:
        pre = regs_pre_push.get(key)
        post = regs_post_push.get(key)
        if pre != post:
            changed = True
            pre_s = f"0x{pre:08X}" if pre is not None else "N/A"
            post_s = f"0x{post:08X}" if post is not None else "N/A"
            print(f"    {key:15s}: {pre_s} → {post_s}")
    if not changed:
        print("    [WARN] NO registers changed! DMA may not have started.")

    # Key checks
    xfer_pre = regs_pre_push.get('XFER_ID', 0) or 0
    xfer_post = regs_post_push.get('XFER_ID', 0) or 0
    print(f"\n  XFER_ID:  {xfer_pre} → {xfer_post} (should increment)")

    src_addr = regs_post_push.get('SRC_ADDR')
    x_length = regs_post_push.get('X_LENGTH')
    if src_addr:
        print(f"  SRC_ADDR: 0x{src_addr:08X} (DDR buffer address)")
    if x_length:
        print(f"  X_LENGTH: 0x{x_length:08X} ({x_length+1} bytes)")

    status = regs_post_push.get('STATUS')
    if status is not None:
        print(f"  STATUS:   0x{status:08X}")

    # ============================================================
    # STAGE 6: Wait and do multiple ADC captures
    # ============================================================
    print("\n--- Stage 6: ADC captures with TX active ---")
    time.sleep(2.0)

    rms_values = []
    for capture in range(3):
        rx_buf2 = iio.Buffer(rx_dev, RX_CAPTURE, False)
        for _ in range(3):
            rx_buf2.refill()
        rx_buf2.refill()
        raw2 = rx_buf2.read()
        data2 = np.frombuffer(raw2, dtype=np.int16)
        I = data2[0::2].astype(np.float64)
        Q = data2[1::2].astype(np.float64)
        rms = np.sqrt(np.mean(I**2 + Q**2))
        rms_values.append(rms)
        ratio = rms / max(rms_base, 1.0)
        print(f"  Capture {capture+1}: RMS={rms:.1f} ({ratio:.1f}x baseline, "
              f"{20*np.log10(max(ratio,0.001)):.1f} dB)")

        if capture == 0:
            # FFT on first capture
            complex_sig = I + 1j * Q
            fft_out = np.fft.fftshift(np.fft.fft(complex_sig * np.hanning(len(complex_sig))))
            fft_mag = 20 * np.log10(np.abs(fft_out) + 1e-12)
            freqs = np.fft.fftshift(np.fft.fftfreq(len(complex_sig), 1.0 / SAMPLE_RATE)) / 1e6

            peak_idx = np.argmax(fft_mag)
            peak_freq = freqs[peak_idx]
            peak_power = fft_mag[peak_idx]
            noise_floor = np.median(fft_mag)
            print(f"    Peak: {peak_freq:.3f} MHz at {peak_power:.1f} dB "
                  f"(noise floor: {noise_floor:.1f} dB, SNR: {peak_power-noise_floor:.1f} dB)")

        del rx_buf2
        time.sleep(0.5)

    # ============================================================
    # STAGE 7: Read DMA registers AFTER captures (check activity)
    # ============================================================
    print("\n--- Stage 7: DAC DMA state AFTER wait ---")
    regs_after = read_dma_regs(DAC_DMA_BASE)

    # Check for counter changes
    print("  DMA activity check (comparing post-push vs after-wait):")
    for key in ['XFER_ID', 'XFER_DONE', 'ACTIVE_ID', 'STATUS', 'CUR_SRC']:
        post = regs_post_push.get(key)
        after = regs_after.get(key)
        if post != after:
            post_s = f"0x{post:08X}" if post is not None else "N/A"
            after_s = f"0x{after:08X}" if after is not None else "N/A"
            print(f"    {key:15s}: {post_s} → {after_s} (CHANGED)")
        else:
            val_s = f"0x{post:08X}" if post is not None else "N/A"
            print(f"    {key:15s}: {val_s} (unchanged)")

    # ============================================================
    # STAGE 8: Diagnosis
    # ============================================================
    print("\n" + "=" * 65)
    print("  DIAGNOSIS")
    print("=" * 65)

    avg_rms = np.mean(rms_values)
    rms_ratio = avg_rms / max(rms_base, 1.0)

    if rms_ratio > 5.0:
        print(f"  [PASS] Strong TX signal detected ({rms_ratio:.1f}x baseline)")
        print(f"  The DAC data path is WORKING.")
        print(f"  If TX_BYPASS=1: this confirms the DAC→AD9361→RF path is OK.")
        print(f"  If TX_BYPASS=0: the OFDM TX chain is producing output!")
    elif rms_ratio > 2.0:
        print(f"  [WARN] Weak TX signal ({rms_ratio:.1f}x baseline)")
        print(f"  Some data is reaching the DAC but at low power.")
        print(f"  Check: OFDM TX output amplitude, DAC FIFO timing.")
    else:
        print(f"  [FAIL] No TX signal detected ({rms_ratio:.1f}x baseline)")
        print()

        # Check if DMA started
        xfer_changed = (regs_pre_push.get('XFER_ID') != regs_post_push.get('XFER_ID'))
        src_valid = (regs_post_push.get('SRC_ADDR', 0) or 0) > 0

        if not xfer_changed and not src_valid:
            print("  LIKELY CAUSE: DAC DMA never started a transfer.")
            print("  The IIO buffer push may not have programmed the DMA.")
            print("  Check:")
            print("    - dmesg for DMA errors")
            print("    - IIO buffer push return status")
            print("    - cf-ad9361-dds-core-lpc device status")
        else:
            print("  DMA appears to be running (XFER_ID or SRC_ADDR changed).")
            print()

            # Check data_sel
            dac_sel = devmem_read(DAC_CHAN0_BASE + DAC_DATA_SEL_OFF)
            if dac_sel is not None:
                sel = dac_sel & 0xF
                if sel != 2:
                    print(f"  LIKELY CAUSE: axi_ad9361 DAC data_sel = {sel} (not DMA).")
                    print("  The AD9361 is NOT using DMA data on dac_data ports.")
                    print("  It may be in DDS mode (0) or zero mode (9).")
                    print("  Fix: Force DMA mode by writing:")
                    print(f"    devmem 0x{DAC_CHAN0_BASE + DAC_DATA_SEL_OFF:08X} 32 0x00000002")
                    print(f"    devmem 0x{DAC_CHAN1_BASE + DAC_DATA_SEL_OFF:08X} 32 0x00000002")
                else:
                    print("  DAC data_sel = 2 (DMA mode) — correct.")
                    print()
                    print("  LIKELY CAUSE: din_valid_in_0_0 (txValid) never asserts.")
                    print("  The axi_ad9361_dac_fifo has no data from OFDM TX.")
                    print("  Possible issues:")
                    print("    1. OFDM_Tx never produces output (txValid stuck LOW)")
                    print("    2. Backpressure stalls the pipeline")
                    print("    3. OFDM_Tx is processing but hasn't finished a frame yet")
                    print()
                    print("  NEXT STEP: Build with TX_BYPASS=1 and re-run this test.")
                    print("  If bypass mode works, the DAC path is OK and the")
                    print("  issue is in the OFDM TX chain (TX_Top/HDLC/OFDM_Tx).")

    print()
    print("  To build with TX_BYPASS=1, add to ofdm_top instantiation:")
    print("    defparam ofdm_top.TX_BYPASS = 1;")
    print("  Or set in Vivado: ofdm_top > TX_BYPASS = 1")
    print("=" * 65)


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""
test_13_force_dma_loopback.py — Force DAC to DMA Mode & End-to-End Loopback Test

PURPOSE:
  test_12 revealed that dac_data_sel stays at 0 (DDS mode) even after IIO push,
  because the modified BD (without util_upack) prevents the IIO driver from
  auto-switching to DMA mode.

  This test:
    1. Forces dac_data_sel = 2 (DMA mode) via devmem for ALL DAC channels
    2. Pushes IIO TX buffer to feed data into the OFDM TX chain
    3. Verifies strong RF output via ADC capture + FFT
    4. Reads back OFDM RX decoded data via the RX DMA path
    5. Provides comprehensive pass/fail diagnosis

FIXES APPLIED IN THIS BUILD:
  - Prepare_Inputs.v: shift <<< 5 (was 4) to output sfix16_En14 matching OFDM_Rx
  - RX_Top.v: explicit wire declarations for impairment control signals
  - ofdm_top.v: TX_BYPASS parameter + bypass tone MUX (default TX_BYPASS=0)
"""

import sys
import time
import subprocess
import struct
import numpy as np

try:
    import iio
except ImportError:
    print("[FAIL] pylibiio not installed")
    sys.exit(1)

# =====================================================================
# Configuration
# =====================================================================
SAMPLE_RATE  = 30720000
CENTER_FREQ  = 2400000000
RF_BW        = 20000000
TX_ATTEN     = -10.0       # dB (moderate power for loopback)
RX_GAIN      = 60.0        # dB
TX_SAMPLES   = 32768
RX_CAPTURE   = 16384
NUM_CAPTURES = 5           # Multiple captures to catch OFDM frames

# =====================================================================
# Hardware Addresses
# =====================================================================
DAC_DMA_BASE     = 0x7C420000
ADC_DMA_BASE     = 0x7C400000
OFDM_RX_DMA_BASE = 0x7C440000   # OFDM RX DMA (from add_ofdm_rx_dma.tcl)
AXI_AD9361_BASE  = 0x79020000

# axi_ad9361 DAC channel base addresses
DAC_CHAN_BASES = {
    "I0": AXI_AD9361_BASE + 0x0400,
    "Q0": AXI_AD9361_BASE + 0x0440,
    "I1": AXI_AD9361_BASE + 0x0480,
    "Q1": AXI_AD9361_BASE + 0x04C0,
}
DAC_DATA_SEL_OFF = 0x0018   # REG_CHAN_CNTRL_7 offset

# Data sel names
DATA_SEL_NAMES = {
    0: "DDS_tone", 1: "SED_pattern", 2: "DMA_data",
    8: "PN7", 9: "zero_output", 10: "PN15",
    11: "PRBS_seq", 12: "input_sel"
}


def devmem_read(addr):
    """Read a 32-bit register via devmem"""
    try:
        r = subprocess.run(["devmem", f"0x{addr:08X}", "32"],
                           capture_output=True, text=True, timeout=5)
        if r.returncode == 0:
            return int(r.stdout.strip(), 16)
    except Exception as e:
        print(f"    devmem read 0x{addr:08X} failed: {e}")
    return None


def devmem_write(addr, val):
    """Write a 32-bit register via devmem"""
    try:
        r = subprocess.run(["devmem", f"0x{addr:08X}", "32", f"0x{val:08X}"],
                           capture_output=True, text=True, timeout=5)
        return r.returncode == 0
    except Exception as e:
        print(f"    devmem write 0x{addr:08X} = 0x{val:08X} failed: {e}")
    return False


def read_dac_data_sel():
    """Read dac_data_sel for all channels, return dict"""
    result = {}
    for name, base in DAC_CHAN_BASES.items():
        val = devmem_read(base + DAC_DATA_SEL_OFF)
        if val is not None:
            sel = val & 0xF
            result[name] = sel
        else:
            result[name] = None
    return result


def force_dac_dma_mode():
    """Force ALL DAC channels to DMA data mode (sel=2)"""
    print("  Forcing dac_data_sel = 2 (DMA mode) for all channels...")
    success = True
    for name, base in DAC_CHAN_BASES.items():
        addr = base + DAC_DATA_SEL_OFF
        ok = devmem_write(addr, 0x00000002)
        if ok:
            # Verify
            readback = devmem_read(addr)
            if readback is not None and (readback & 0xF) == 2:
                print(f"    DAC {name}: set to DMA_data (2) ✓")
            else:
                print(f"    DAC {name}: VERIFY FAILED (readback=0x{readback:08X})" if readback else f"    DAC {name}: VERIFY FAILED")
                success = False
        else:
            print(f"    DAC {name}: WRITE FAILED")
            success = False
    return success


def read_dma_regs(base, reg_list=None):
    """Read DMA registers"""
    if reg_list is None:
        reg_list = {
            'VERSION':   0x000,
            'CTRL':      0x080,
            'XFER_ID':   0x084,
            'FLAGS':     0x400,
            'SRC_ADDR':  0x408,
            'X_LENGTH':  0x40C,
            'STATUS':    0x434,
            'CUR_SRC':   0x43C,
        }
    regs = {}
    for name, offset in reg_list.items():
        regs[name] = devmem_read(base + offset)
    return regs


def main():
    print("=" * 70)
    print("  test_13: Force DAC DMA Mode & End-to-End Loopback Test")
    print("=" * 70)

    # ============================================================
    # STAGE 1: Find IIO devices
    # ============================================================
    print("\n[Stage 1] Finding IIO devices...")
    ctx = iio.Context()
    phy = rx_dev = tx_dev = None
    for dev in ctx.devices:
        if dev.name == "ad9361-phy":
            phy = dev
        elif dev.name == "cf-ad9361-lpc":
            rx_dev = dev
        elif dev.name == "cf-ad9361-dds-core-lpc":
            tx_dev = dev

    if not all([phy, rx_dev, tx_dev]):
        missing = []
        if not phy:     missing.append("ad9361-phy")
        if not rx_dev:  missing.append("cf-ad9361-lpc")
        if not tx_dev:  missing.append("cf-ad9361-dds-core-lpc")
        print(f"  [FAIL] Missing IIO devices: {', '.join(missing)}")
        return
    print("  All IIO devices found ✓")

    # ============================================================
    # STAGE 2: Read initial dac_data_sel state
    # ============================================================
    print("\n[Stage 2] Initial DAC data_sel state...")
    initial_sel = read_dac_data_sel()
    for name, sel in initial_sel.items():
        sel_name = DATA_SEL_NAMES.get(sel, f"unknown({sel})") if sel is not None else "READ_FAIL"
        print(f"  DAC {name}: dac_data_sel = {sel} ({sel_name})")

    # ============================================================
    # STAGE 3: Configure AD9361
    # ============================================================
    print("\n[Stage 3] Configuring AD9361...")
    phy.find_channel("voltage0", False).attrs["sampling_frequency"].value = str(SAMPLE_RATE)
    phy.find_channel("altvoltage0", True).attrs["frequency"].value = str(CENTER_FREQ)
    phy.find_channel("altvoltage1", True).attrs["frequency"].value = str(CENTER_FREQ)
    phy.find_channel("voltage0", False).attrs["rf_bandwidth"].value = str(RF_BW)
    phy.find_channel("voltage0", True).attrs["rf_bandwidth"].value = str(RF_BW)
    phy.find_channel("voltage0", True).attrs["hardwaregain"].value = str(TX_ATTEN)
    phy.find_channel("voltage0", False).attrs["gain_control_mode"].value = "manual"
    phy.find_channel("voltage0", False).attrs["hardwaregain"].value = str(RX_GAIN)
    print(f"  Fs={SAMPLE_RATE/1e6} MHz, Fc={CENTER_FREQ/1e9} GHz, "
          f"TxAtten={TX_ATTEN} dB, RxGain={RX_GAIN} dB ✓")

    # Disable DDS tones (set all scales to 0)
    for ch_id in range(8):
        ch = tx_dev.find_channel(f"altvoltage{ch_id}", True)
        if ch:
            ch.attrs["scale"].value = "0"
    print("  DDS tones disabled ✓")

    # ============================================================
    # STAGE 4: Capture ADC baseline (before TX)
    # ============================================================
    print("\n[Stage 4] ADC baseline capture (no TX)...")
    rx_i = rx_dev.find_channel("voltage0", False)
    rx_q = rx_dev.find_channel("voltage1", False)
    rx_i.enabled = True
    rx_q.enabled = True

    rx_buf = iio.Buffer(rx_dev, RX_CAPTURE, False)
    for _ in range(5):
        rx_buf.refill()
    raw = rx_buf.read()
    data = np.frombuffer(raw, dtype=np.int16)
    I_base = data[0::2].astype(np.float64)
    Q_base = data[1::2].astype(np.float64)
    rms_base = np.sqrt(np.mean(I_base**2 + Q_base**2))
    print(f"  Baseline RMS: {rms_base:.1f}")
    del rx_buf

    # ============================================================
    # STAGE 5: Push IIO TX buffer (feeds data to DAC DMA → OFDM TX)
    # ============================================================
    print("\n[Stage 5] Pushing IIO TX buffer...")

    # Read DAC DMA before push
    dma_before = read_dma_regs(DAC_DMA_BASE)

    tx_i_ch = tx_dev.find_channel("voltage0", True)
    tx_q_ch = tx_dev.find_channel("voltage1", True)
    tx_i_ch.enabled = True
    tx_q_ch.enabled = True

    tx_buf = iio.Buffer(tx_dev, TX_SAMPLES, True)  # cyclic

    # Generate test payload — alternating ramp pattern
    payload = np.zeros(TX_SAMPLES * 2, dtype=np.int16)
    for i in range(0, len(payload), 2):
        val = np.int16((i // 2) % 256)
        payload[i]     = val   # I
        payload[i + 1] = val   # Q

    tx_buf.write(bytearray(payload.tobytes()))
    tx_buf.push()
    print("  TX buffer pushed (cyclic) ✓")
    time.sleep(0.3)

    # ============================================================
    # STAGE 6: FORCE dac_data_sel = 2 (DMA mode) ← THE KEY FIX
    # ============================================================
    print("\n[Stage 6] *** FORCING DAC to DMA MODE ***")

    # Check if IIO push already set it
    post_push_sel = read_dac_data_sel()
    already_dma = all(v == 2 for v in post_push_sel.values() if v is not None)

    if already_dma:
        print("  dac_data_sel already = 2 (DMA mode) after IIO push ✓")
    else:
        print("  dac_data_sel NOT in DMA mode after IIO push (expected issue)")
        for name, sel in post_push_sel.items():
            sel_name = DATA_SEL_NAMES.get(sel, "?") if sel is not None else "?"
            print(f"    {name}: {sel} ({sel_name})")

        # Force it
        ok = force_dac_dma_mode()
        if not ok:
            print("  [FAIL] Could not force DAC to DMA mode!")
            print("  Cannot proceed with TX test.")
            return
        print("  DAC forced to DMA mode ✓")

    # Verify final state
    final_sel = read_dac_data_sel()
    print("\n  Final dac_data_sel state:")
    all_dma = True
    for name, sel in final_sel.items():
        sel_name = DATA_SEL_NAMES.get(sel, "?") if sel is not None else "?"
        status = "✓" if sel == 2 else "✗"
        print(f"    DAC {name}: {sel} ({sel_name}) {status}")
        if sel != 2:
            all_dma = False

    if not all_dma:
        print("  [FAIL] Not all DAC channels in DMA mode!")
        return

    # ============================================================
    # STAGE 7: Wait for OFDM TX to process and capture ADC
    # ============================================================
    print("\n[Stage 7] Waiting 3s for OFDM TX to produce frames...")
    time.sleep(3.0)

    print("\n  ADC captures with TX active + DAC in DMA mode:")
    rms_values = []
    fft_done = False

    for cap_num in range(NUM_CAPTURES):
        rx_buf2 = iio.Buffer(rx_dev, RX_CAPTURE, False)
        for _ in range(3):
            rx_buf2.refill()
        rx_buf2.refill()
        raw2 = rx_buf2.read()
        data2 = np.frombuffer(raw2, dtype=np.int16)
        I = data2[0::2].astype(np.float64)
        Q = data2[1::2].astype(np.float64)
        rms = np.sqrt(np.mean(I**2 + Q**2))
        rms_values.append(rms)
        ratio = rms / max(rms_base, 1.0)
        db = 20 * np.log10(max(ratio, 0.001))
        print(f"  Capture {cap_num+1}/{NUM_CAPTURES}: RMS={rms:.1f} "
              f"({ratio:.1f}x baseline, {db:.1f} dB)")

        # FFT on first capture with signal
        if not fft_done and rms > rms_base * 1.5:
            complex_sig = I + 1j * Q
            win = np.hanning(len(complex_sig))
            fft_out = np.fft.fftshift(np.fft.fft(complex_sig * win))
            fft_mag = 20 * np.log10(np.abs(fft_out) + 1e-12)
            freqs = np.fft.fftshift(np.fft.fftfreq(len(complex_sig), 1.0/SAMPLE_RATE)) / 1e6

            peak_idx = np.argmax(fft_mag)
            peak_freq = freqs[peak_idx]
            peak_power = fft_mag[peak_idx]
            noise_floor = np.median(fft_mag)
            snr = peak_power - noise_floor

            print(f"    FFT: Peak={peak_freq:.3f} MHz, Power={peak_power:.1f} dB, "
                  f"Floor={noise_floor:.1f} dB, SNR={snr:.1f} dB")

            # Occupied bandwidth (3 dB from peak)
            above_threshold = fft_mag > (peak_power - 20)
            bw_bins = np.sum(above_threshold)
            occ_bw = bw_bins * (SAMPLE_RATE / len(complex_sig)) / 1e6
            print(f"    Occupied BW (-20dB): ~{occ_bw:.2f} MHz")

            if occ_bw > 2.0:
                print(f"    [INFO] Wideband signal — consistent with OFDM")
            elif snr > 30:
                print(f"    [INFO] Narrowband tone — possibly bypass or DDS leakage")

            fft_done = True

        del rx_buf2
        time.sleep(0.5)

    # ============================================================
    # STAGE 8: Check DAC DMA activity after test
    # ============================================================
    print("\n[Stage 8] DAC DMA activity check...")
    dma_after = read_dma_regs(DAC_DMA_BASE)

    print("  Key DMA registers (before push → after test):")
    for key in ['XFER_ID', 'FLAGS', 'SRC_ADDR', 'X_LENGTH', 'STATUS', 'CUR_SRC']:
        b = dma_before.get(key)
        a = dma_after.get(key)
        b_s = f"0x{b:08X}" if b is not None else "N/A"
        a_s = f"0x{a:08X}" if a is not None else "N/A"
        changed = " (CHANGED)" if b != a else ""
        print(f"    {key:12s}: {b_s} → {a_s}{changed}")

    # ============================================================
    # STAGE 9: Check OFDM RX DMA (decoded data path)
    # ============================================================
    print("\n[Stage 9] OFDM RX DMA check...")
    rx_dma_regs = {
        'VERSION':  0x000,
        'CTRL':     0x080,
        'XFER_ID':  0x084,
        'FLAGS':    0x400,
        'DEST_ADDR': 0x404,
        'X_LENGTH': 0x40C,
        'STATUS':   0x434,
        'CUR_DEST': 0x438,
    }
    for name, offset in rx_dma_regs.items():
        val = devmem_read(OFDM_RX_DMA_BASE + offset)
        if val is not None:
            print(f"    {name:12s}: 0x{val:08X}")
        else:
            print(f"    {name:12s}: READ FAILED")

    ofdm_rx_ver = devmem_read(OFDM_RX_DMA_BASE + 0x000)
    if ofdm_rx_ver is None or ofdm_rx_ver == 0:
        print("  [WARN] OFDM RX DMA not responding — may not be in bitstream")
        print("         This is expected if bitstream hasn't been rebuilt with")
        print("         add_ofdm_rx_dma.tcl changes.")
    else:
        ofdm_rx_ctrl = devmem_read(OFDM_RX_DMA_BASE + 0x080)
        ofdm_rx_xfer = devmem_read(OFDM_RX_DMA_BASE + 0x084)
        ofdm_rx_dest = devmem_read(OFDM_RX_DMA_BASE + 0x438)
        print(f"  OFDM RX DMA: version=0x{ofdm_rx_ver:08X}, "
              f"ctrl=0x{ofdm_rx_ctrl:08X if ofdm_rx_ctrl else 0:08X}, "
              f"xfer_id=0x{ofdm_rx_xfer:08X if ofdm_rx_xfer else 0:08X}")

    # ============================================================
    # STAGE 10: Re-check dac_data_sel (driver may reset it)
    # ============================================================
    print("\n[Stage 10] Final dac_data_sel check (driver may have reset)...")
    final_check = read_dac_data_sel()
    for name, sel in final_check.items():
        sel_name = DATA_SEL_NAMES.get(sel, "?") if sel is not None else "?"
        print(f"    DAC {name}: {sel} ({sel_name})")
        if sel != 2:
            print(f"    [WARN] Driver reset {name} back from DMA mode!")

    # ============================================================
    # STAGE 11: Diagnosis
    # ============================================================
    print("\n" + "=" * 70)
    print("  DIAGNOSIS")
    print("=" * 70)

    avg_rms = np.mean(rms_values)
    max_rms = np.max(rms_values)
    rms_ratio = avg_rms / max(rms_base, 1.0)
    max_ratio = max_rms / max(rms_base, 1.0)

    print(f"\n  Baseline RMS:    {rms_base:.1f}")
    print(f"  Average TX RMS:  {avg_rms:.1f} ({rms_ratio:.1f}x baseline)")
    print(f"  Peak TX RMS:     {max_rms:.1f} ({max_ratio:.1f}x baseline)")

    if rms_ratio > 10.0:
        print(f"\n  ✓ STRONG TX signal detected ({rms_ratio:.1f}x baseline)")
        print(f"  The OFDM TX chain is producing RF output!")
        print(f"  The DAC DMA → OFDM TX → AD9361 DAC path is WORKING.")
        print()
        print(f"  NEXT STEPS:")
        print(f"    1. Check OFDM RX decoded data via DMA readback")
        print(f"    2. Run BER test (test_10_ber_test.py)")
        print(f"    3. If RX data issues persist, check Signal Tap for:")
        print(f"       - dataBitsValid (OFDM_Rx decoded bit valid)")
        print(f"       - header_detected (0x7E frame sync)")
        print(f"       - dec_valid_out (final decoded word valid)")

    elif rms_ratio > 3.0:
        print(f"\n  ~ MODERATE TX signal ({rms_ratio:.1f}x baseline)")
        print(f"  OFDM TX is producing output but amplitude is low.")
        print()

        # Check if intermittent
        above_5x = sum(1 for r in rms_values if r > rms_base * 5)
        if above_5x > 0 and above_5x < NUM_CAPTURES:
            print(f"  Signal is INTERMITTENT ({above_5x}/{NUM_CAPTURES} captures above 5x).")
            print(f"  This is NORMAL for OFDM — frames are bursty.")
            print(f"  The TX chain IS working.")
        else:
            print(f"  Possible causes:")
            print(f"    - OFDM TX output amplitude is small (sfix16_En13 range)")
            print(f"    - Increase TX attenuation (currently {TX_ATTEN} dB)")
            print(f"    - dac_data_sel may have reverted (check Stage 10 above)")

    elif rms_ratio > 1.5:
        print(f"\n  ! WEAK TX signal ({rms_ratio:.1f}x baseline)")
        print(f"  Possible issues:")
        print(f"    1. dac_data_sel reverted to DDS (check Stage 10)")
        print(f"    2. OFDM TX hasn't completed a frame yet")
        print(f"    3. txValid is too intermittent")
        print()

        # Re-check data sel
        recheck = read_dac_data_sel()
        reverted = any(v != 2 for v in recheck.values() if v is not None)
        if reverted:
            print(f"  ** dac_data_sel REVERTED — IIO driver is overwriting our devmem! **")
            print(f"  SOLUTION: The IIO driver periodically resets dac_data_sel.")
            print(f"  Options:")
            print(f"    A. Modify axi_ad9361 HDL to hardwire dac_data_sel = 2")
            print(f"    B. Write a continuous devmem loop to keep forcing it")
            print(f"    C. Patch the Linux driver to not reset dac_data_sel")

    else:
        print(f"\n  ✗ NO TX signal detected ({rms_ratio:.1f}x baseline)")
        print()

        recheck = read_dac_data_sel()
        reverted = any(v != 2 for v in recheck.values() if v is not None)
        if reverted:
            print(f"  ROOT CAUSE: dac_data_sel REVERTED to non-DMA mode!")
            print(f"  The IIO driver is continuously overwriting our devmem force.")
            print(f"  SOLUTION: Hardwire dac_data_sel = 2 in axi_ad9361 HDL")
        else:
            print(f"  dac_data_sel stayed at 2 — issue is elsewhere.")
            print(f"  Check Signal Tap:")
            print(f"    - Is txValid going HIGH?")
            print(f"    - Is din_data_0_0 changing?")
            print(f"    - Is the DAC FIFO draining (din_valid_in_0_0)?")

    # Summary
    print()
    print("  dac_data_sel fix applied: devmem force to DMA mode (2)")
    print("  NOTE: If driver reverts, need HDL-level fix in axi_ad9361")
    print("=" * 70)


if __name__ == "__main__":
    main()

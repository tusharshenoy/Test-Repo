#!/usr/bin/env python3
"""
test_05_rx_capture.py — Capture raw RX IQ samples from AD9361 ADC
With loopback cable: captures whatever TX is sending.
Without cable: captures noise floor / ambient RF.

Saves data to files for offline analysis.
"""

import sys
import os
import time
import numpy as np

try:
    import iio
except ImportError:
    print("[FAIL] pylibiio not installed. Run: pip3 install pylibiio")
    sys.exit(1)

# -------------------------------------------------------
# Configuration
# -------------------------------------------------------
SAMPLE_RATE  = 30720000     # 30.72 MSPS
CENTER_FREQ  = 2400000000   # 2.4 GHz
RF_BW        = 20000000     # 20 MHz
RX_GAIN      = 60.0         # dB (high gain for OFDM signal detection)
NUM_SAMPLES  = 16384        # per buffer
NUM_BUFFERS  = 20           # total buffers to capture
SKIP_BUFFERS = 3            # skip initial transient buffers
OUTPUT_BIN   = "rx_capture.bin"
OUTPUT_CSV   = "rx_capture.csv"


def main():
    print("============================================")
    print("  TEST 05: RX IQ Sample Capture")
    print("============================================")
    print("")

    PASS = 0
    FAIL = 0

    # Connect to IIO
    try:
        ctx = iio.Context()
    except Exception as e:
        print(f"[FAIL] Cannot create IIO context: {e}")
        return 1

    # Find devices
    phy = None
    rx_dev = None
    for dev in ctx.devices:
        if dev.name == "ad9361-phy":
            phy = dev
        elif dev.name == "cf-ad9361-lpc":
            rx_dev = dev

    if not phy or not rx_dev:
        print("[FAIL] Required IIO devices not found")
        return 1

    # -----------------------------------------------------------
    # 1. Configure AD9361 RX
    # -----------------------------------------------------------
    print("[1] Configuring AD9361 RX...")
    try:
        phy.find_channel("voltage0", is_output=False).attrs["sampling_frequency"].value = str(SAMPLE_RATE)
        phy.find_channel("altvoltage0", is_output=True).attrs["frequency"].value = str(CENTER_FREQ)
        phy.find_channel("voltage0", is_output=False).attrs["rf_bandwidth"].value = str(RF_BW)
        phy.find_channel("voltage0", is_output=False).attrs["gain_control_mode"].value = "manual"
        phy.find_channel("voltage0", is_output=False).attrs["hardwaregain"].value = str(float(RX_GAIN))
        PASS += 1
        print("  [PASS] RX configured")
        print(f"  Freq: {CENTER_FREQ/1e9} GHz, Rate: {SAMPLE_RATE/1e6} MSPS, Gain: {RX_GAIN} dB")
    except Exception as e:
        print(f"  [FAIL] RX config error: {e}")
        FAIL += 1
        return 1

    # -----------------------------------------------------------
    # 2. Enable RX channels and create buffer
    # -----------------------------------------------------------
    print("\n[2] Setting up RX capture...")
    rx_i = rx_dev.find_channel("voltage0", is_output=False)
    rx_q = rx_dev.find_channel("voltage1", is_output=False)
    if not rx_i or not rx_q:
        print("  [FAIL] Cannot find RX I/Q channels")
        return 1

    rx_i.enabled = True
    rx_q.enabled = True
    rx_buf = iio.Buffer(rx_dev, NUM_SAMPLES, False)
    PASS += 1
    print(f"  [PASS] RX buffer created ({NUM_SAMPLES} samples)")

    # -----------------------------------------------------------
    # 3. Capture data
    # -----------------------------------------------------------
    print(f"\n[3] Capturing {NUM_BUFFERS} buffers...")
    all_i = []
    all_q = []

    for buf_idx in range(NUM_BUFFERS):
        rx_buf.refill()
        raw = np.frombuffer(rx_buf.read(), dtype=np.int16)
        i_data = raw[0::2].astype(np.float64)
        q_data = raw[1::2].astype(np.float64)

        if buf_idx >= SKIP_BUFFERS:
            all_i.append(i_data)
            all_q.append(q_data)

        if (buf_idx + 1) % 5 == 0:
            print(f"  Captured buffer {buf_idx + 1}/{NUM_BUFFERS}")

    rx_i_data = np.concatenate(all_i)
    rx_q_data = np.concatenate(all_q)
    total_samples = len(rx_i_data)
    PASS += 1
    print(f"  [PASS] Captured {total_samples} samples ({total_samples/SAMPLE_RATE*1000:.1f} ms)")

    # -----------------------------------------------------------
    # 4. Basic statistics
    # -----------------------------------------------------------
    print("\n[4] Signal statistics...")

    i_mean = np.mean(rx_i_data)
    q_mean = np.mean(rx_q_data)
    i_std = np.std(rx_i_data)
    q_std = np.std(rx_q_data)
    i_peak = np.max(np.abs(rx_i_data))
    q_peak = np.max(np.abs(rx_q_data))
    rms = np.sqrt(np.mean(rx_i_data**2 + rx_q_data**2))
    power_db = 10 * np.log10(np.mean(rx_i_data**2 + rx_q_data**2) + 1e-10)

    print(f"  I channel: mean={i_mean:.1f}, std={i_std:.1f}, peak={i_peak:.0f}")
    print(f"  Q channel: mean={q_mean:.1f}, std={q_std:.1f}, peak={q_peak:.0f}")
    print(f"  DC offset: I={i_mean:.1f}, Q={q_mean:.1f}")
    print(f"  RMS: {rms:.1f}")
    print(f"  Power: {power_db:.1f} dB (relative)")

    # Check for clipping
    CLIP_THRESHOLD = 32000  # near int16 max
    if i_peak > CLIP_THRESHOLD or q_peak > CLIP_THRESHOLD:
        print(f"  [WARN] Signal may be clipping! Peak={max(i_peak,q_peak):.0f}")
        print("  Consider reducing RX gain.")
    else:
        PASS += 1
        print("  [PASS] No clipping detected")

    # -----------------------------------------------------------
    # 5. FFT analysis
    # -----------------------------------------------------------
    print("\n[5] FFT analysis...")
    fft_len = min(NUM_SAMPLES, len(rx_i_data))
    rx_complex = rx_i_data[:fft_len] + 1j * rx_q_data[:fft_len]

    # Apply window
    window = np.hanning(fft_len)
    rx_windowed = rx_complex * window

    fft_vals = np.fft.fftshift(np.fft.fft(rx_windowed))
    fft_mag = np.abs(fft_vals)
    fft_db = 20 * np.log10(fft_mag + 1e-10)
    freqs = np.fft.fftshift(np.fft.fftfreq(fft_len, 1.0/SAMPLE_RATE))

    # Find peaks
    peak_idx = np.argmax(fft_db)
    peak_freq = freqs[peak_idx]
    peak_db = fft_db[peak_idx]

    # Noise floor (median of FFT)
    noise_floor = np.median(fft_db)
    snr = peak_db - noise_floor

    print(f"  FFT size: {fft_len}")
    print(f"  Peak frequency: {peak_freq/1e6:.3f} MHz (offset from center)")
    print(f"  Peak power: {peak_db:.1f} dB")
    print(f"  Noise floor: {noise_floor:.1f} dB")
    print(f"  SNR: {snr:.1f} dB")

    # Find top 5 peaks
    print("\n  Top 5 spectral peaks:")
    fft_db_copy = fft_db.copy()
    for rank in range(5):
        idx = np.argmax(fft_db_copy)
        f = freqs[idx]
        p = fft_db_copy[idx]
        print(f"    {rank+1}. {f/1e6:+8.3f} MHz  {p:7.1f} dB")
        # Null out this peak and neighbors
        lo = max(0, idx - 10)
        hi = min(len(fft_db_copy), idx + 10)
        fft_db_copy[lo:hi] = -200

    # -----------------------------------------------------------
    # 6. Save to files
    # -----------------------------------------------------------
    print(f"\n[6] Saving data...")

    # Binary file (interleaved int16 I/Q)
    save_data = np.empty(total_samples * 2, dtype=np.int16)
    save_data[0::2] = rx_i_data.astype(np.int16)
    save_data[1::2] = rx_q_data.astype(np.int16)

    with open(OUTPUT_BIN, 'wb') as f:
        f.write(save_data.tobytes())
    bin_size = os.path.getsize(OUTPUT_BIN)
    print(f"  Binary: {OUTPUT_BIN} ({bin_size} bytes)")

    # CSV (first 1000 samples for quick inspection)
    csv_len = min(1000, total_samples)
    with open(OUTPUT_CSV, 'w') as f:
        f.write("sample,I,Q\n")
        for s in range(csv_len):
            f.write(f"{s},{int(rx_i_data[s])},{int(rx_q_data[s])}\n")
    print(f"  CSV: {OUTPUT_CSV} ({csv_len} samples)")

    PASS += 1
    print("  [PASS] Data saved")

    # -----------------------------------------------------------
    # Summary
    # -----------------------------------------------------------
    print("")
    print("============================================")
    print(f"  TEST 05 RESULT: {PASS} passed, {FAIL} failed")
    if FAIL == 0:
        print("  STATUS: PASS")
    else:
        print("  STATUS: FAIL")
    print("")
    print(f"  Captured {total_samples} samples @ {SAMPLE_RATE/1e6} MSPS")
    print(f"  Duration: {total_samples/SAMPLE_RATE*1000:.1f} ms")
    print(f"  Files: {OUTPUT_BIN}, {OUTPUT_CSV}")
    print("")
    print("  To analyze in MATLAB/Python:")
    print(f"    data = np.fromfile('{OUTPUT_BIN}', dtype=np.int16)")
    print("    I, Q = data[0::2], data[1::2]")
    print("============================================")

    return 0 if FAIL == 0 else 1


if __name__ == "__main__":
    sys.exit(main())

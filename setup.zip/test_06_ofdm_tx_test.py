#!/usr/bin/env python3
"""
test_06_ofdm_tx_test.py — OFDM TX chain diagnostics
Requires: TX1A → RX1A (direct SMA cable loopback)

Data path under test:
  PS → DAC DMA (0x7C420000) → PS_PL_FIFO (64→16b) → TX_Top
    → HDLC (0x7E framing) → OFDM_Tx (QPSK, 128-FFT)
    → din_data_0/1 → DAC FIFO → AD9361 DAC → RF

This test diagnoses why the OFDM TX chain may not produce output
by checking DMA registers, comparing DDS vs DMA modes, and
measuring power levels at each stage.
"""

import sys
import os
import time
import struct
import subprocess
import numpy as np

try:
    import iio
except ImportError:
    print("[FAIL] pylibiio not installed. Run: pip3 install pylibiio")
    sys.exit(1)

# -------------------------------------------------------
# Configuration
# -------------------------------------------------------
SAMPLE_RATE  = 30720000     # 30.72 MSPS
CENTER_FREQ  = 2400000000   # 2.4 GHz
RF_BW        = 20000000     # 20 MHz
TX_ATTEN     = -10.0        # dB (output ~-3 dBm, safe below AD9361 +2.5 dBm max RX input)
RX_GAIN      = 60.0         # dB (high gain needed for OFDM signal detection)
NUM_SAMPLES  = 16384        # per buffer
NUM_CAPTURE  = 10           # RX buffers
SKIP_BUFFERS = 3

# DMA register addresses (axi_ad9361_dac_dma at 0x7C420000)
DAC_DMA_BASE = 0x7C420000
DMA_REG_VERSION    = 0x000
DMA_REG_IRQ_PEND   = 0x024
DMA_REG_CTRL       = 0x400
DMA_REG_STATUS     = 0x428
DMA_REG_FLAGS      = 0x40C
DMA_REG_XFER_DONE  = 0x418

# ADC DMA register addresses (axi_ad9361_adc_dma at 0x7C400000)
ADC_DMA_BASE = 0x7C400000


def devmem_read(addr):
    """Read a 32-bit register via devmem."""
    try:
        result = subprocess.run(
            ["devmem", f"0x{addr:08X}", "32"],
            capture_output=True, text=True, timeout=5
        )
        if result.returncode == 0:
            return int(result.stdout.strip(), 16)
    except FileNotFoundError:
        # Try devmem2 if devmem not available
        try:
            result = subprocess.run(
                ["devmem2", f"0x{addr:08X}", "w"],
                capture_output=True, text=True, timeout=5
            )
            if result.returncode == 0:
                for line in result.stdout.split('\n'):
                    if 'Value at address' in line or ':' in line:
                        parts = line.split()
                        for p in parts:
                            if p.startswith('0x') or p.startswith('0X'):
                                return int(p, 16)
        except FileNotFoundError:
            pass
    except Exception:
        pass
    return None


def find_devices(ctx):
    phy = rx_dev = tx_dev = None
    for dev in ctx.devices:
        if dev.name == "ad9361-phy":
            phy = dev
        elif dev.name == "cf-ad9361-lpc":
            rx_dev = dev
        elif dev.name == "cf-ad9361-dds-core-lpc":
            tx_dev = dev
    return phy, rx_dev, tx_dev


def capture_rx_power(rx_dev, num_samples, num_buffers, skip):
    """Capture RX and compute average power in dB."""
    rx_i = rx_dev.find_channel("voltage0", is_output=False)
    rx_q = rx_dev.find_channel("voltage1", is_output=False)
    rx_i.enabled = True
    rx_q.enabled = True
    rx_buf = iio.Buffer(rx_dev, num_samples, False)

    all_power = []
    for buf_idx in range(num_buffers):
        rx_buf.refill()
        raw = np.frombuffer(rx_buf.read(), dtype=np.int16)
        i_data = raw[0::2].astype(np.float64)
        q_data = raw[1::2].astype(np.float64)
        if buf_idx >= skip:
            pwr = np.mean(i_data**2 + q_data**2)
            all_power.append(pwr)

    rx_i.enabled = False
    rx_q.enabled = False

    if all_power:
        avg_pwr = np.mean(all_power)
        rms = np.sqrt(avg_pwr)
        return 10 * np.log10(avg_pwr + 1e-10), rms
    return -100.0, 0.0


def main():
    print("============================================")
    print("  TEST 06: OFDM TX Chain Diagnostics")
    print("============================================")
    print("")
    print("[PREREQ] Connect: TX1A → RX1A (direct SMA cable)")
    print("")

    PASS = 0
    FAIL = 0
    INFO = 0

    # Connect
    try:
        ctx = iio.Context()
    except Exception as e:
        print(f"[FAIL] Cannot create IIO context: {e}")
        return 1

    phy, rx_dev, tx_dev = find_devices(ctx)
    if not all([phy, rx_dev, tx_dev]):
        print("[FAIL] Not all IIO devices found")
        return 1

    # -----------------------------------------------------------
    # 1. Configure AD9361
    # -----------------------------------------------------------
    print("[1] Configuring AD9361...")
    try:
        phy.find_channel("voltage0", is_output=False).attrs["sampling_frequency"].value = str(SAMPLE_RATE)
        phy.find_channel("altvoltage0", is_output=True).attrs["frequency"].value = str(CENTER_FREQ)
        phy.find_channel("altvoltage1", is_output=True).attrs["frequency"].value = str(CENTER_FREQ)
        phy.find_channel("voltage0", is_output=False).attrs["rf_bandwidth"].value = str(RF_BW)
        phy.find_channel("voltage0", is_output=True).attrs["rf_bandwidth"].value = str(RF_BW)
        phy.find_channel("voltage0", is_output=True).attrs["hardwaregain"].value = str(TX_ATTEN)
        phy.find_channel("voltage0", is_output=False).attrs["gain_control_mode"].value = "manual"
        phy.find_channel("voltage0", is_output=False).attrs["hardwaregain"].value = str(RX_GAIN)
        PASS += 1
        print("  [PASS] AD9361 configured")
    except Exception as e:
        print(f"  [FAIL] {e}")
        return 1

    # -----------------------------------------------------------
    # 2. Verify RF path with DDS tone first
    # -----------------------------------------------------------
    print("\n[2] Verifying RF path with DDS tone...")
    try:
        ch = tx_dev.find_channel("altvoltage0", is_output=True)
        ch.attrs["frequency"].value = "1000000"
        ch.attrs["scale"].value = "0.5"
        ch.attrs["phase"].value = "0"
        ch = tx_dev.find_channel("altvoltage1", is_output=True)
        ch.attrs["scale"].value = "0"
        ch = tx_dev.find_channel("altvoltage2", is_output=True)
        ch.attrs["frequency"].value = "1000000"
        ch.attrs["scale"].value = "0.5"
        ch.attrs["phase"].value = "90000"
        ch = tx_dev.find_channel("altvoltage3", is_output=True)
        ch.attrs["scale"].value = "0"
    except Exception as e:
        print(f"  [WARN] DDS setup error: {e}")

    time.sleep(0.5)
    dds_power, dds_rms = capture_rx_power(rx_dev, NUM_SAMPLES, NUM_CAPTURE, SKIP_BUFFERS)
    print(f"  DDS TX → RX power: {dds_power:.1f} dB (RMS={dds_rms:.1f})")

    if dds_rms > 20:
        PASS += 1
        print("  [PASS] RF loopback verified via DDS")
    else:
        FAIL += 1
        print("  [FAIL] No DDS signal on RX — check SMA cable!")
        print("         Cannot proceed without working RF loopback.")
        return 1

    # -----------------------------------------------------------
    # 3. Check DAC DMA registers
    # -----------------------------------------------------------
    print("\n[3] Checking DAC DMA registers (0x7C420000)...")
    dma_version = devmem_read(DAC_DMA_BASE + DMA_REG_VERSION)
    dma_ctrl    = devmem_read(DAC_DMA_BASE + DMA_REG_CTRL)
    dma_status  = devmem_read(DAC_DMA_BASE + DMA_REG_STATUS)
    dma_flags   = devmem_read(DAC_DMA_BASE + DMA_REG_FLAGS)

    if dma_version is not None:
        print(f"  DMA Version:  0x{dma_version:08X}")
        print(f"  DMA Control:  0x{dma_ctrl:08X}" if dma_ctrl is not None else "  DMA Control:  N/A")
        print(f"  DMA Status:   0x{dma_status:08X}" if dma_status is not None else "  DMA Status:   N/A")
        print(f"  DMA Flags:    0x{dma_flags:08X}" if dma_flags is not None else "  DMA Flags:    N/A")

        if dma_ctrl is not None and (dma_ctrl & 0x1):
            INFO += 1
            print("  [INFO] DMA is enabled (CTRL bit 0 = 1)")
        else:
            INFO += 1
            print("  [INFO] DMA not currently enabled (will be enabled by buffer push)")
    else:
        print("  [WARN] Cannot read DMA registers (devmem/devmem2 not available)")
        print("         Install: opkg install devmem2")

    # -----------------------------------------------------------
    # 4. Disable DDS, push DMA data through OFDM chain
    # -----------------------------------------------------------
    print("\n[4] Switching to DMA mode (disabling DDS)...")
    try:
        for ch_id in range(8):
            ch = tx_dev.find_channel(f"altvoltage{ch_id}", is_output=True)
            if ch:
                ch.attrs["scale"].value = "0"
        print("  DDS disabled")
    except Exception as e:
        print(f"  [WARN] {e}")

    # Capture baseline (no TX)
    time.sleep(0.3)
    baseline_power, baseline_rms = capture_rx_power(rx_dev, NUM_SAMPLES, 5, 2)
    print(f"  Baseline (no TX): {baseline_power:.1f} dB (RMS={baseline_rms:.1f})")

    # Enable TX channels for DMA buffer
    print("\n  Pushing data via TX DMA buffer...")
    try:
        tx_i = tx_dev.find_channel("voltage0", is_output=True)
        tx_q = tx_dev.find_channel("voltage1", is_output=True)
        if not tx_i or not tx_q:
            print("  [FAIL] TX voltage channels not found")
            FAIL += 1
        else:
            tx_i.enabled = True
            tx_q.enabled = True

            tx_buf = iio.Buffer(tx_dev, NUM_SAMPLES, True)  # cyclic

            # Generate test data — payload bytes for OFDM TX
            # PS_PL_FIFO receives 64-bit AXI words, unpacks to 16-bit
            # TX_Top HDLC framer reads 16-bit words as payload
            payload = np.zeros(NUM_SAMPLES * 2, dtype=np.int16)
            for i in range(0, len(payload), 2):
                payload[i]     = np.int16(0x5555)   # I channel: test pattern
                payload[i + 1] = np.int16(0x3333)   # Q channel: test pattern

            tx_buf.write(bytearray(payload.tobytes()))
            tx_buf.push()
            print(f"  TX buffer pushed ({len(payload)} int16 samples, cyclic)")

            # Wait for OFDM chain to process
            print("  Waiting 3s for OFDM TX chain to produce output...")
            time.sleep(3)

    except Exception as e:
        print(f"  [FAIL] TX DMA error: {e}")
        FAIL += 1

    # -----------------------------------------------------------
    # 5. Check DMA status after push
    # -----------------------------------------------------------
    print("\n[5] DMA status after buffer push...")
    dma_ctrl_after  = devmem_read(DAC_DMA_BASE + DMA_REG_CTRL)
    dma_status_after = devmem_read(DAC_DMA_BASE + DMA_REG_STATUS)
    dma_xfer = devmem_read(DAC_DMA_BASE + DMA_REG_XFER_DONE)

    if dma_ctrl_after is not None:
        print(f"  DMA Control:  0x{dma_ctrl_after:08X}")
        print(f"  DMA Status:   0x{dma_status_after:08X}" if dma_status_after is not None else "  DMA Status:   N/A")
        print(f"  DMA Xfer:     0x{dma_xfer:08X}" if dma_xfer is not None else "  DMA Xfer:     N/A")

        if dma_ctrl_after is not None and (dma_ctrl_after & 0x1):
            PASS += 1
            print("  [PASS] DMA is running after push")
        else:
            FAIL += 1
            print("  [FAIL] DMA not running — IIO driver may not have started transfer")
    else:
        print("  [WARN] Cannot read DMA registers")

    # -----------------------------------------------------------
    # 6. Capture RX with OFDM TX active
    # -----------------------------------------------------------
    print("\n[6] Capturing RX with OFDM TX active...")
    active_power, active_rms = capture_rx_power(rx_dev, NUM_SAMPLES, NUM_CAPTURE, SKIP_BUFFERS)
    print(f"  Active RX power: {active_power:.1f} dB (RMS={active_rms:.1f})")

    power_delta = active_power - baseline_power
    print(f"  Power delta:     {power_delta:+.1f} dB")
    print(f"  DDS reference:   {dds_power:.1f} dB (RMS={dds_rms:.1f})")

    # -----------------------------------------------------------
    # 7. Detailed FFT analysis
    # -----------------------------------------------------------
    print("\n[7] Spectral analysis of OFDM TX output...")
    rx_i_ch = rx_dev.find_channel("voltage0", is_output=False)
    rx_q_ch = rx_dev.find_channel("voltage1", is_output=False)
    rx_i_ch.enabled = True
    rx_q_ch.enabled = True
    rx_buf = iio.Buffer(rx_dev, NUM_SAMPLES, False)

    for _ in range(SKIP_BUFFERS):
        rx_buf.refill()
    rx_buf.refill()
    raw = np.frombuffer(rx_buf.read(), dtype=np.int16)
    i_data = raw[0::2].astype(np.float64)
    q_data = raw[1::2].astype(np.float64)

    rx_complex = i_data + 1j * q_data
    window = np.hanning(len(rx_complex))
    fft_vals = np.fft.fftshift(np.fft.fft(rx_complex * window))
    fft_db = 20 * np.log10(np.abs(fft_vals) + 1e-10)
    freqs = np.fft.fftshift(np.fft.fftfreq(len(rx_complex), 1.0/SAMPLE_RATE))

    noise_floor = np.median(fft_db)
    peak_idx = np.argmax(fft_db)
    peak_freq = freqs[peak_idx]
    peak_db = fft_db[peak_idx]

    # Check for any signal above noise
    above_noise = fft_db > (noise_floor + 10)
    signal_bins = np.sum(above_noise)
    occupied_bw = signal_bins * (SAMPLE_RATE / len(fft_db))

    print(f"  Peak: {peak_freq/1e6:.3f} MHz at {peak_db:.1f} dB")
    print(f"  Noise floor: {noise_floor:.1f} dB")
    print(f"  Bins above noise+10dB: {signal_bins}")
    print(f"  Occupied BW: {occupied_bw/1e6:.2f} MHz")

    rx_i_ch.enabled = False
    rx_q_ch.enabled = False

    # -----------------------------------------------------------
    # 8. Diagnosis
    # -----------------------------------------------------------
    print("\n============================================")
    print("  DIAGNOSIS:")

    if power_delta >= 6:
        PASS += 1
        print(f"  [PASS] OFDM TX signal detected (+{power_delta:.1f} dB)")
    elif power_delta >= 2:
        INFO += 1
        print(f"  [INFO] Weak OFDM TX signal (+{power_delta:.1f} dB)")
        print("         OFDM chain may be partially working.")
        print("         Try increasing TX power or reducing attenuation.")
    else:
        FAIL += 1
        print(f"  [FAIL] No OFDM TX signal detected (+{power_delta:.1f} dB)")
        print("")
        print("  Likely causes:")
        print("  1. OFDM_Tx 'ready' signal not asserted → HDLC stalls")
        print("     → Check with ILA: probe txReady in TX_Top")
        print("  2. PS_PL_FIFO empty → DMA not streaming data")
        print("     → Check DMA registers (devmem 0x7C420428)")
        print("  3. OFDM_Tx not producing valid IQ output")
        print("     → Check txValid, txData_re/im with ILA")
        print("  4. DAC FIFO ignoring OFDM output (din_valid issue)")
        print("     → Check din_valid_in_0_0 in axi_ad9361_dac_fifo")
        print("")
        print("  Debug steps:")
        print("    a) Add ILA to Vivado: probe txReady, txValid,")
        print("       m_axis_valid_0, empty, full in ofdm_top")
        print("    b) Check DMA: devmem 0x7C420400 (CTRL)")
        print("       devmem 0x7C420428 (STATUS)")
        print("    c) Verify clock: util_ad9361_divclk_clk_out")
        print("       drives both ofdm_top.clk and DMA m_axis_aclk")

    print(f"\n  TEST 06 RESULT: {PASS} passed, {FAIL} failed, {INFO} info")
    status = "PASS" if FAIL == 0 else "FAIL"
    print(f"  STATUS: {status}")
    print("============================================")
    return 0 if FAIL == 0 else 1


if __name__ == "__main__":
    sys.exit(main())

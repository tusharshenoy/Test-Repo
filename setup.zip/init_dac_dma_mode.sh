#!/bin/bash
# =============================================================================
# init_dac_dma_mode.sh — Force DAC data_sel to DMA mode (2)
# =============================================================================
# Forces all 4 DAC channels' dac_data_sel register to 2 (DMA_data mode).
# The IIO driver defaults to DDS mode (0) after boot. This script overrides
# that so the OFDM TX data path reaches the AD9361 DAC.
#
# Usage:
#   sudo ./init_dac_dma_mode.sh           # one-shot force
#   sudo ./init_dac_dma_mode.sh --watch   # continuous force (every 100ms)
#   sudo ./init_dac_dma_mode.sh --verify  # read-back only (no write)
#
# Registers:
#   AXI_AD9361 base = 0x79020000
#   DAC channel offsets: I0=+0x400, Q0=+0x440, I1=+0x480, Q1=+0x4C0
#   dac_data_sel offset within channel = +0x18
#   Value 2 = DMA_data mode
# =============================================================================

set -euo pipefail

# DAC data_sel register addresses
DAC_I0=0x79020418
DAC_Q0=0x79020458
DAC_I1=0x79020498
DAC_Q1=0x790204D8
DMA_MODE=0x00000002

CHANNELS=("I0:$DAC_I0" "Q0:$DAC_Q0" "I1:$DAC_I1" "Q1:$DAC_Q1")

DATA_SEL_NAMES=(
    [0]="DDS_tone"
    [1]="SED_pattern"
    [2]="DMA_data"
    [8]="PN7"
    [9]="zero_output"
    [10]="PN15"
    [11]="PRBS_seq"
    [12]="input_sel"
)

read_sel() {
    local addr=$1
    devmem "$addr" 32 2>/dev/null | sed 's/^0x//' | tr '[:lower:]' '[:upper:]'
}

get_sel_name() {
    local val=$1
    local name="${DATA_SEL_NAMES[$val]:-unknown}"
    echo "$name"
}

verify_channels() {
    local all_ok=1
    for entry in "${CHANNELS[@]}"; do
        local name="${entry%%:*}"
        local addr="${entry##*:}"
        local raw
        raw=$(read_sel "$addr")
        local val=$((16#$raw))
        local sel_name
        sel_name=$(get_sel_name "$val")
        if [ "$val" -eq 2 ]; then
            echo "  DAC $name [$(printf '0x%s' "$addr")]: $val ($sel_name) [OK]"
        else
            echo "  DAC $name [$(printf '0x%s' "$addr")]: $val ($sel_name) [WRONG — expected 2 (DMA_data)]"
            all_ok=0
        fi
    done
    return $((1 - all_ok))
}

force_all() {
    for entry in "${CHANNELS[@]}"; do
        local name="${entry%%:*}"
        local addr="${entry##*:}"
        devmem "$addr" 32 "$DMA_MODE"
    done
}

# --- Main ---
echo "============================================"
echo "  DAC data_sel → DMA mode (2)"
echo "============================================"

MODE="${1:-}"

case "$MODE" in
    --verify)
        echo "[VERIFY] Reading dac_data_sel registers..."
        verify_channels
        ;;
    --watch)
        echo "[WATCH] Continuously forcing dac_data_sel = 2 (Ctrl+C to stop)..."
        force_all
        echo "[INFO] Initial force done. Entering watch loop (100ms interval)..."
        trap 'echo ""; echo "[STOP] Watch stopped."; exit 0' INT TERM
        FORCE_COUNT=0
        REVERT_COUNT=0
        while true; do
            for entry in "${CHANNELS[@]}"; do
                local_addr="${entry##*:}"
                raw=$(read_sel "$local_addr")
                val=$((16#$raw))
                if [ "$val" -ne 2 ]; then
                    devmem "$local_addr" 32 "$DMA_MODE"
                    REVERT_COUNT=$((REVERT_COUNT + 1))
                fi
            done
            FORCE_COUNT=$((FORCE_COUNT + 1))
            if [ $((FORCE_COUNT % 100)) -eq 0 ]; then
                echo "[WATCH] Checked $FORCE_COUNT times, re-forced $REVERT_COUNT reverts"
            fi
            sleep 0.1
        done
        ;;
    *)
        echo "[1/3] Reading current dac_data_sel values..."
        verify_channels || true
        echo ""
        echo "[2/3] Forcing all channels to DMA mode (2)..."
        force_all
        echo "  Done."
        echo ""
        echo "[3/3] Verifying..."
        if verify_channels; then
            echo ""
            echo "[OK] All DAC channels set to DMA mode."
        else
            echo ""
            echo "[WARN] Some channels did not stick. IIO driver may be reverting."
            echo "       Try: sudo ./init_dac_dma_mode.sh --watch"
        fi
        echo "============================================"
        ;;
esac

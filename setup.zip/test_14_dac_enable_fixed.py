#!/usr/bin/env python3
"""
test_14_dac_enable_fixed.py — DAC FIFO Enable Fix Verification

PURPOSE:
  After applying fix_dac_fifo_enable.tcl (forces dout_enable = 1 on the DAC FIFO),
  this test verifies the OFDM TX signal reaches the AD9361 DAC.

  It also continuously forces dac_data_sel = 2 (DMA mode) in a background thread,
  preventing the IIO driver from reverting it back to DDS mode.

PREREQUISITES:
  - Bitstream rebuilt after running fix_dac_fifo_enable.tcl in Vivado
  - New bitstream deployed to ZedBoard

TEST FLOW:
  1. Start background thread to continuously force dac_data_sel = 2
  2. Configure AD9361 (2.4 GHz, 30.72 MSPS)
  3. Capture ADC baseline
  4. Push IIO TX buffer (feeds OFDM TX chain)
  5. Multiple ADC captures with FFT analysis
  6. Check for OFDM wideband signal
  7. Read OFDM RX DMA registers (decoded data check)
"""

import sys
import time
import subprocess
import threading
import numpy as np

try:
    import iio
except ImportError:
    print("[FAIL] pylibiio not installed")
    sys.exit(1)

# =====================================================================
# Configuration
# =====================================================================
SAMPLE_RATE  = 30720000
CENTER_FREQ  = 2400000000
RF_BW        = 20000000
TX_ATTEN     = -10.0
RX_GAIN      = 60.0
TX_SAMPLES   = 32768
RX_CAPTURE   = 16384
NUM_CAPTURES = 8            # More captures to catch OFDM frame bursts
FORCE_INTERVAL = 0.005      # 5ms force interval for dac_data_sel

# =====================================================================
# Hardware Addresses
# =====================================================================
AXI_AD9361_BASE  = 0x79020000
DAC_DMA_BASE     = 0x7C420000
OFDM_RX_DMA_BASE = 0x7C440000

DAC_CHAN_BASES = {
    "I0": AXI_AD9361_BASE + 0x0400,
    "Q0": AXI_AD9361_BASE + 0x0440,
    "I1": AXI_AD9361_BASE + 0x0480,
    "Q1": AXI_AD9361_BASE + 0x04C0,
}
DAC_DATA_SEL_OFF = 0x0018

DATA_SEL_NAMES = {
    0: "DDS_tone", 1: "SED_pattern", 2: "DMA_data",
    8: "PN7", 9: "zero_output", 10: "PN15",
    11: "PRBS_seq", 12: "input_sel"
}


def devmem_read(addr):
    try:
        r = subprocess.run(["devmem", f"0x{addr:08X}", "32"],
                           capture_output=True, text=True, timeout=5)
        if r.returncode == 0:
            return int(r.stdout.strip(), 16)
    except Exception:
        pass
    return None


def devmem_write(addr, val):
    try:
        r = subprocess.run(["devmem", f"0x{addr:08X}", "32", f"0x{val:08X}"],
                           capture_output=True, text=True, timeout=5)
        return r.returncode == 0
    except Exception:
        pass
    return False


class DacSelForcer:
    """Background thread that continuously forces dac_data_sel = 2 (DMA mode)"""

    def __init__(self, interval=0.005):
        self.interval = interval
        self._stop = threading.Event()
        self._thread = None
        self.force_count = 0
        self.revert_count = 0

    def start(self):
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()

    def stop(self):
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=2)

    def _run(self):
        while not self._stop.is_set():
            for name, base in [("I0", DAC_CHAN_BASES["I0"]),
                               ("Q0", DAC_CHAN_BASES["Q0"])]:
                addr = base + DAC_DATA_SEL_OFF
                val = devmem_read(addr)
                if val is not None and (val & 0xF) != 2:
                    devmem_write(addr, 0x00000002)
                    self.revert_count += 1
                self.force_count += 1
            self._stop.wait(self.interval)


def main():
    print("=" * 70)
    print("  test_14: DAC FIFO Enable Fix Verification")
    print("=" * 70)

    # ============================================================
    # STAGE 1: Find IIO devices
    # ============================================================
    print("\n[Stage 1] Finding IIO devices...")
    ctx = iio.Context()
    phy = rx_dev = tx_dev = None
    for dev in ctx.devices:
        if dev.name == "ad9361-phy":
            phy = dev
        elif dev.name == "cf-ad9361-lpc":
            rx_dev = dev
        elif dev.name == "cf-ad9361-dds-core-lpc":
            tx_dev = dev

    if not all([phy, rx_dev, tx_dev]):
        print("[FAIL] Missing IIO devices")
        return
    print("  All IIO devices found")

    # ============================================================
    # STAGE 2: Start background dac_data_sel forcer
    # ============================================================
    print("\n[Stage 2] Starting background dac_data_sel forcer (DMA mode)...")
    forcer = DacSelForcer(interval=FORCE_INTERVAL)
    forcer.start()
    time.sleep(0.1)

    # Check initial state
    for name, base in DAC_CHAN_BASES.items():
        val = devmem_read(base + DAC_DATA_SEL_OFF)
        if val is not None:
            sel = val & 0xF
            sel_name = DATA_SEL_NAMES.get(sel, f"unknown({sel})")
            print(f"  DAC {name}: dac_data_sel = {sel} ({sel_name})")

    # ============================================================
    # STAGE 3: Configure AD9361
    # ============================================================
    print("\n[Stage 3] Configuring AD9361...")
    phy.find_channel("voltage0", False).attrs["sampling_frequency"].value = str(SAMPLE_RATE)
    phy.find_channel("altvoltage0", True).attrs["frequency"].value = str(CENTER_FREQ)
    phy.find_channel("altvoltage1", True).attrs["frequency"].value = str(CENTER_FREQ)
    phy.find_channel("voltage0", False).attrs["rf_bandwidth"].value = str(RF_BW)
    phy.find_channel("voltage0", True).attrs["rf_bandwidth"].value = str(RF_BW)
    phy.find_channel("voltage0", True).attrs["hardwaregain"].value = str(TX_ATTEN)
    phy.find_channel("voltage0", False).attrs["gain_control_mode"].value = "manual"
    phy.find_channel("voltage0", False).attrs["hardwaregain"].value = str(RX_GAIN)

    for ch_id in range(8):
        ch = tx_dev.find_channel(f"altvoltage{ch_id}", True)
        if ch:
            ch.attrs["scale"].value = "0"

    print(f"  Fs={SAMPLE_RATE/1e6} MHz, Fc={CENTER_FREQ/1e9} GHz, "
          f"TxAtten={TX_ATTEN} dB, RxGain={RX_GAIN} dB")

    # ============================================================
    # STAGE 4: ADC baseline
    # ============================================================
    print("\n[Stage 4] ADC baseline (no TX)...")
    rx_i = rx_dev.find_channel("voltage0", False)
    rx_q = rx_dev.find_channel("voltage1", False)
    rx_i.enabled = True
    rx_q.enabled = True

    rx_buf = iio.Buffer(rx_dev, RX_CAPTURE, False)
    for _ in range(5):
        rx_buf.refill()
    raw = rx_buf.read()
    data = np.frombuffer(raw, dtype=np.int16)
    I_base = data[0::2].astype(np.float64)
    Q_base = data[1::2].astype(np.float64)
    rms_base = np.sqrt(np.mean(I_base**2 + Q_base**2))
    print(f"  Baseline RMS: {rms_base:.1f}")
    del rx_buf

    # ============================================================
    # STAGE 5: Push IIO TX buffer
    # ============================================================
    print("\n[Stage 5] Pushing IIO TX buffer...")
    tx_i_ch = tx_dev.find_channel("voltage0", True)
    tx_q_ch = tx_dev.find_channel("voltage1", True)
    tx_i_ch.enabled = True
    tx_q_ch.enabled = True

    tx_buf = iio.Buffer(tx_dev, TX_SAMPLES, True)  # cyclic

    # Generate ramp payload
    payload = np.zeros(TX_SAMPLES * 2, dtype=np.int16)
    for i in range(0, len(payload), 2):
        val = np.int16((i // 2) % 256)
        payload[i]     = val
        payload[i + 1] = val

    tx_buf.write(bytearray(payload.tobytes()))
    tx_buf.push()
    print("  TX buffer pushed (cyclic)")

    # Give the forcer time to re-assert after IIO push
    time.sleep(0.5)
    print(f"  Background forcer stats: {forcer.force_count} checks, "
          f"{forcer.revert_count} reverts corrected")

    # Verify dac_data_sel is 2
    for name in ["I0", "Q0"]:
        val = devmem_read(DAC_CHAN_BASES[name] + DAC_DATA_SEL_OFF)
        if val is not None:
            sel = val & 0xF
            sel_name = DATA_SEL_NAMES.get(sel, "?")
            status = "OK" if sel == 2 else "WRONG"
            print(f"  DAC {name}: dac_data_sel = {sel} ({sel_name}) [{status}]")

    # ============================================================
    # STAGE 6: Wait for OFDM TX and capture ADC
    # ============================================================
    print(f"\n[Stage 6] Waiting 3s then capturing ADC ({NUM_CAPTURES} captures)...")
    time.sleep(3.0)

    rms_values = []
    best_fft = None

    for cap_num in range(NUM_CAPTURES):
        rx_buf2 = iio.Buffer(rx_dev, RX_CAPTURE, False)
        for _ in range(3):
            rx_buf2.refill()
        rx_buf2.refill()
        raw2 = rx_buf2.read()
        data2 = np.frombuffer(raw2, dtype=np.int16)
        I = data2[0::2].astype(np.float64)
        Q = data2[1::2].astype(np.float64)
        rms = np.sqrt(np.mean(I**2 + Q**2))
        rms_values.append(rms)
        ratio = rms / max(rms_base, 1.0)
        db = 20 * np.log10(max(ratio, 0.001))
        print(f"  Capture {cap_num+1}/{NUM_CAPTURES}: RMS={rms:.1f} "
              f"({ratio:.1f}x baseline, {db:.1f} dB)")

        # FFT on captures with signal
        if rms > rms_base * 1.2:
            complex_sig = I + 1j * Q
            win = np.hanning(len(complex_sig))
            fft_out = np.fft.fftshift(np.fft.fft(complex_sig * win))
            fft_mag = 20 * np.log10(np.abs(fft_out) + 1e-12)
            freqs = np.fft.fftshift(np.fft.fftfreq(len(complex_sig), 1.0/SAMPLE_RATE)) / 1e6

            peak_idx = np.argmax(fft_mag)
            peak_freq = freqs[peak_idx]
            peak_power = fft_mag[peak_idx]
            noise_floor = np.median(fft_mag)
            snr = peak_power - noise_floor

            # Occupied bandwidth (-20dB from peak)
            above_threshold = fft_mag > (peak_power - 20)
            bw_bins = np.sum(above_threshold)
            occ_bw = bw_bins * (SAMPLE_RATE / len(complex_sig)) / 1e6

            print(f"    FFT: Peak={peak_freq:.3f} MHz, SNR={snr:.1f} dB, "
                  f"BW(-20dB)={occ_bw:.2f} MHz")

            if best_fft is None or rms > best_fft['rms']:
                best_fft = {
                    'rms': rms, 'peak_freq': peak_freq, 'snr': snr,
                    'occ_bw': occ_bw, 'peak_power': peak_power,
                    'noise_floor': noise_floor
                }

        del rx_buf2
        time.sleep(0.3)

    # ============================================================
    # STAGE 7: Check DMA registers
    # ============================================================
    print("\n[Stage 7] DAC DMA registers...")
    dac_dma_regs = {
        'CTRL': 0x080, 'XFER_ID': 0x084, 'FLAGS': 0x400,
        'SRC_ADDR': 0x408, 'X_LENGTH': 0x40C, 'STATUS': 0x434,
    }
    for name, offset in dac_dma_regs.items():
        val = devmem_read(DAC_DMA_BASE + offset)
        print(f"  {name:12s}: 0x{val:08X}" if val is not None else f"  {name:12s}: READ FAILED")

    # ============================================================
    # STAGE 8: OFDM RX DMA check
    # ============================================================
    print("\n[Stage 8] OFDM RX DMA registers...")
    rx_dma_regs = {
        'VERSION': 0x000, 'CTRL': 0x080, 'XFER_ID': 0x084,
        'FLAGS': 0x400, 'DEST_ADDR': 0x404, 'X_LENGTH': 0x40C,
        'STATUS': 0x434, 'CUR_DEST': 0x438,
    }
    for name, offset in rx_dma_regs.items():
        val = devmem_read(OFDM_RX_DMA_BASE + offset)
        if val is not None:
            print(f"  {name:12s}: 0x{val:08X}")
        else:
            print(f"  {name:12s}: READ FAILED")

    # ============================================================
    # STAGE 9: Stop forcer and check final state
    # ============================================================
    print("\n[Stage 9] Stopping background forcer...")
    forcer.stop()
    print(f"  Total: {forcer.force_count} checks, {forcer.revert_count} reverts corrected")

    # Final dac_data_sel check
    for name, base in [("I0", DAC_CHAN_BASES["I0"]),
                       ("Q0", DAC_CHAN_BASES["Q0"])]:
        val = devmem_read(base + DAC_DATA_SEL_OFF)
        if val is not None:
            sel = val & 0xF
            sel_name = DATA_SEL_NAMES.get(sel, "?")
            print(f"  DAC {name}: dac_data_sel = {sel} ({sel_name})")

    # ============================================================
    # STAGE 10: Diagnosis
    # ============================================================
    print("\n" + "=" * 70)
    print("  DIAGNOSIS")
    print("=" * 70)

    avg_rms = np.mean(rms_values)
    max_rms = np.max(rms_values)
    rms_ratio = avg_rms / max(rms_base, 1.0)
    max_ratio = max_rms / max(rms_base, 1.0)

    print(f"\n  Baseline RMS:    {rms_base:.1f}")
    print(f"  Average TX RMS:  {avg_rms:.1f} ({rms_ratio:.1f}x baseline)")
    print(f"  Peak TX RMS:     {max_rms:.1f} ({max_ratio:.1f}x baseline)")
    print(f"  Forcer reverts:  {forcer.revert_count}")

    if best_fft:
        print(f"\n  Best FFT: Peak={best_fft['peak_freq']:.3f} MHz, "
              f"SNR={best_fft['snr']:.1f} dB, BW={best_fft['occ_bw']:.2f} MHz")

    if max_ratio > 10.0:
        print(f"\n  >>> STRONG TX signal! ({max_ratio:.1f}x baseline) <<<")
        print(f"  The DAC FIFO enable fix is WORKING!")
        print(f"  OFDM TX data is reaching the AD9361 DAC.")
        if best_fft and best_fft['occ_bw'] > 2.0:
            print(f"  Wideband signal ({best_fft['occ_bw']:.1f} MHz) = OFDM confirmed!")
        print(f"\n  NEXT: Check OFDM RX decoded data (run BER test)")

    elif max_ratio > 3.0:
        print(f"\n  ~ Moderate signal ({max_ratio:.1f}x baseline)")
        above = sum(1 for r in rms_values if r > rms_base * 5)
        if above > 0:
            print(f"  Intermittent: {above}/{NUM_CAPTURES} captures above 5x")
            print(f"  This is NORMAL for bursty OFDM frames.")
        else:
            print(f"  Signal is consistent but weak.")
            print(f"  Check: OFDM TX amplitude, dac_data_sel stability")

    elif max_ratio > 1.5:
        print(f"\n  ! Weak signal ({max_ratio:.1f}x baseline)")
        if forcer.revert_count > 10:
            print(f"  Driver reverted dac_data_sel {forcer.revert_count} times!")
            print(f"  The continuous forcing is fighting the driver.")
            print(f"  This suggests the IIO driver actively resets dac_data_sel.")
        print(f"\n  Check with ILA/Signal Tap:")
        print(f"    - Is din_enable_0 HIGH on the DAC FIFO? (FIFO fix working?)")
        print(f"    - Is dout_data_0 changing? (data flowing through FIFO?)")
        print(f"    - Is dac_data_sel = 2 when capturing? (check in real-time)")

    else:
        print(f"\n  X NO signal detected ({max_ratio:.1f}x baseline)")
        print()
        if forcer.revert_count > 20:
            print(f"  Driver reverted {forcer.revert_count} times — driver wins!")
            print(f"  SOLUTION: Must hardcode dac_data_sel = 2 in the axi_ad9361 HDL")
            print(f"  OR disable the cf-ad9361-dds-core-lpc IIO driver")
        else:
            print(f"  Forcer reverts: {forcer.revert_count} (low = driver NOT the issue)")
            print(f"  The issue is likely the DAC FIFO still not flowing data.")
            print(f"  POSSIBLE CAUSES:")
            print(f"    1. fix_dac_fifo_enable.tcl not applied (rebuild needed)")
            print(f"    2. dout_valid from axi_ad9361 is also LOW (need to force)")
            print(f"    3. Clock domain mismatch in FIFO")
            print()
            print(f"  CHECK with Signal Tap / ILA:")
            print(f"    - din_enable_0 on DAC FIFO (should be 1 after BD fix)")
            print(f"    - dout_valid_0 on DAC FIFO (should toggle at sample rate)")
            print(f"    - dout_data_0 on DAC FIFO (should show OFDM TX data)")
            print()
            print(f"  If dout_valid is stuck LOW, add to fix_dac_fifo_enable.tcl:")
            print(f"    Also force dout_valid_0/1/2/3 to constant 1")

    print()
    print("=" * 70)


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""
test_04_tx_tone.py — Transmit CW tone via AD9361 DDS
No RF cable needed (verify with spectrum analyzer if available).

Uses the built-in DDS in cf-ad9361-dds-core-lpc to generate a tone.
This tests the DAC path WITHOUT the OFDM PL logic.
"""

import sys
import time

try:
    import iio
except ImportError:
    print("[FAIL] pylibiio not installed. Run: pip3 install pylibiio")
    sys.exit(1)

# -------------------------------------------------------
# Configuration
# -------------------------------------------------------
CENTER_FREQ  = 2400000000   # 2.4 GHz
SAMPLE_RATE  = 30720000     # 30.72 MSPS
TX_ATTEN     = -10.0        # dB (output ~-3 dBm, safe for direct SMA cable)
DDS_TONE_HZ  = 1000000      # 1 MHz DDS tone
DDS_SCALE    = 0.5          # DDS scale (0.0 - 1.0)
DDS_FREQ_TOL = 500          # Hz tolerance for DDS frequency readback


def main():
    print("============================================")
    print("  TEST 04: TX CW Tone via DDS")
    print("============================================")
    print("")

    PASS = 0
    FAIL = 0

    # Connect to IIO
    try:
        ctx = iio.Context()
    except Exception as e:
        print(f"[FAIL] Cannot create IIO context: {e}")
        return 1

    # Find devices
    phy = None
    tx_dev = None
    for dev in ctx.devices:
        if dev.name == "ad9361-phy":
            phy = dev
        elif dev.name == "cf-ad9361-dds-core-lpc":
            tx_dev = dev

    if not phy:
        print("[FAIL] ad9361-phy not found")
        return 1
    if not tx_dev:
        print("[FAIL] cf-ad9361-dds-core-lpc not found")
        return 1

    # -----------------------------------------------------------
    # 1. Configure AD9361 for TX
    # -----------------------------------------------------------
    print("[1] Configuring AD9361 TX...")
    try:
        phy.find_channel("voltage0", is_output=False).attrs["sampling_frequency"].value = str(SAMPLE_RATE)
        phy.find_channel("altvoltage1", is_output=True).attrs["frequency"].value = str(CENTER_FREQ)
        phy.find_channel("voltage0", is_output=True).attrs["rf_bandwidth"].value = str(SAMPLE_RATE)
        phy.find_channel("voltage0", is_output=True).attrs["hardwaregain"].value = str(float(TX_ATTEN))
        print(f"  TX LO: {CENTER_FREQ/1e9} GHz")
        print(f"  Sample Rate: {SAMPLE_RATE/1e6} MSPS")
        print(f"  TX Atten: {TX_ATTEN} dB")
        PASS += 1
        print("  [PASS] AD9361 TX configured")
    except Exception as e:
        print(f"  [FAIL] Configuration error: {e}")
        FAIL += 1
        return 1

    # -----------------------------------------------------------
    # 2. Configure DDS channels
    # -----------------------------------------------------------
    print("\n[2] Configuring DDS tone...")
    print(f"  Target: {DDS_TONE_HZ/1e6} MHz tone, scale={DDS_SCALE}")

    # DDS has 4 channels per TX: TX1_I_F1, TX1_I_F2, TX1_Q_F1, TX1_Q_F2
    # For a clean single tone, use F1 on both I and Q with 90 degree phase offset
    dds_channels = {}
    for ch in tx_dev.channels:
        if ch.output:
            dds_channels[ch.id] = ch

    if not dds_channels:
        print("  [FAIL] No DDS output channels found")
        return 1

    print(f"  Found {len(dds_channels)} DDS channels:")
    for ch_id in sorted(dds_channels.keys()):
        print(f"    - {ch_id}")

    try:
        # Typical DDS channel mapping for AD9361:
        # altvoltage0 = TX1_I_F1 (I channel, tone 1)
        # altvoltage1 = TX1_I_F2 (I channel, tone 2) — set to 0
        # altvoltage2 = TX1_Q_F1 (Q channel, tone 1)
        # altvoltage3 = TX1_Q_F2 (Q channel, tone 2) — set to 0
        # altvoltage4-7 = TX2 channels (if dual TX)

        # Set TX1 I channel — tone 1
        ch = tx_dev.find_channel("altvoltage0", is_output=True)
        if ch:
            ch.attrs["frequency"].value = str(DDS_TONE_HZ)
            ch.attrs["scale"].value = str(DDS_SCALE)
            ch.attrs["phase"].value = "0"        # 0 degrees
            print(f"  TX1_I_F1: freq={DDS_TONE_HZ}, scale={DDS_SCALE}, phase=0")

        # Disable I channel tone 2
        ch = tx_dev.find_channel("altvoltage1", is_output=True)
        if ch:
            ch.attrs["scale"].value = "0"
            ch.attrs["frequency"].value = str(DDS_TONE_HZ)

        # Set TX1 Q channel — tone 1 (90 degree phase for complex tone)
        ch = tx_dev.find_channel("altvoltage2", is_output=True)
        if ch:
            ch.attrs["frequency"].value = str(DDS_TONE_HZ)
            ch.attrs["scale"].value = str(DDS_SCALE)
            ch.attrs["phase"].value = "90000"    # 90 degrees (in millidegrees)
            print(f"  TX1_Q_F1: freq={DDS_TONE_HZ}, scale={DDS_SCALE}, phase=90000")

        # Disable Q channel tone 2
        ch = tx_dev.find_channel("altvoltage3", is_output=True)
        if ch:
            ch.attrs["scale"].value = "0"
            ch.attrs["frequency"].value = str(DDS_TONE_HZ)

        PASS += 1
        print("  [PASS] DDS channels configured")

    except Exception as e:
        print(f"  [FAIL] DDS config error: {e}")
        FAIL += 1
        return 1

    # -----------------------------------------------------------
    # 3. Verify DDS is active (read back)
    # -----------------------------------------------------------
    print("\n[3] Verifying DDS configuration...")
    try:
        ch0 = tx_dev.find_channel("altvoltage0", is_output=True)
        readback_freq = ch0.attrs["frequency"].value
        readback_scale = ch0.attrs["scale"].value
        freq_error = abs(int(readback_freq) - DDS_TONE_HZ)
        print(f"  DDS readback: freq={readback_freq}, scale={readback_scale}")
        print(f"  Frequency error: {freq_error} Hz (tolerance: {DDS_FREQ_TOL} Hz)")

        if freq_error <= DDS_FREQ_TOL:
            PASS += 1
            print("  [PASS] DDS frequency verified (within tolerance)")
        else:
            FAIL += 1
            print(f"  [FAIL] DDS freq error {freq_error} Hz > {DDS_FREQ_TOL} Hz tolerance")
    except Exception as e:
        print(f"  [WARN] Could not verify DDS: {e}")

    # -----------------------------------------------------------
    # 4. Check ENSM mode
    # -----------------------------------------------------------
    print("\n[4] Checking ENSM state...")
    try:
        ensm = phy.attrs.get("ensm_mode")
        if ensm:
            mode = ensm.value
            print(f"  ENSM mode: {mode}")
            if "tx" in mode.lower() or "fdd" in mode.lower():
                PASS += 1
                print("  [PASS] TX is active")
            else:
                print(f"  [INFO] ENSM mode is '{mode}' — TX may not be transmitting")
                print("  Try setting: echo fdd > /sys/bus/iio/devices/iio:deviceX/ensm_mode")
    except Exception as e:
        print(f"  [INFO] Could not read ENSM: {e}")

    # -----------------------------------------------------------
    # Summary
    # -----------------------------------------------------------
    print("")
    print("============================================")
    print(f"  TEST 04 RESULT: {PASS} passed, {FAIL} failed")

    if FAIL == 0:
        print("  STATUS: PASS")
        print("")
        print("  DDS tone is now transmitting at:")
        print(f"    Center: {CENTER_FREQ/1e9} GHz")
        print(f"    Tone offset: +{DDS_TONE_HZ/1e6} MHz")
        print(f"    RF frequency: {(CENTER_FREQ + DDS_TONE_HZ)/1e9:.6f} GHz")
        print("")
        print("  Verify with spectrum analyzer if available.")
        print("  Run test_05 with loopback cable to capture this tone on RX.")
    else:
        print("  STATUS: FAIL")

    print("============================================")
    return 0 if FAIL == 0 else 1


if __name__ == "__main__":
    sys.exit(main())

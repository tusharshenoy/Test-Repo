#!/bin/bash
# test_08_rf_sweep.sh — AD9361 frequency sweep / PLL lock test
# No RF cable needed

echo "============================================"
echo "  TEST 08: RF Frequency Sweep"
echo "============================================"
echo ""

PASS=0
FAIL=0
LOCK_PASS=0
LOCK_FAIL=0

# Find ad9361-phy device
IIO_DIR="/sys/bus/iio/devices"
PHY_DEV=""

for dev in "$IIO_DIR"/iio:device*; do
    [ ! -f "$dev/name" ] && continue
    if [ "$(cat "$dev/name")" = "ad9361-phy" ]; then
        PHY_DEV="$dev"
        break
    fi
done

if [ -z "$PHY_DEV" ]; then
    echo "[FAIL] ad9361-phy not found"
    exit 1
fi

echo "[INFO] ad9361-phy at: $PHY_DEV"

# -----------------------------------------------------------
# Frequency ranges to test
# AD9361 supports 70 MHz to 6 GHz
# -----------------------------------------------------------
# Format: "frequency_hz label"
FREQS=(
    "70000000    70_MHz"
    "100000000   100_MHz"
    "200000000   200_MHz"
    "400000000   400_MHz"
    "700000000   700_MHz"
    "900000000   900_MHz"
    "1000000000  1.0_GHz"
    "1200000000  1.2_GHz"
    "1500000000  1.5_GHz"
    "1800000000  1.8_GHz"
    "2000000000  2.0_GHz"
    "2400000000  2.4_GHz"
    "2500000000  2.5_GHz"
    "3000000000  3.0_GHz"
    "3500000000  3.5_GHz"
    "4000000000  4.0_GHz"
    "4500000000  4.5_GHz"
    "5000000000  5.0_GHz"
    "5500000000  5.5_GHz"
    "5800000000  5.8_GHz"
    "6000000000  6.0_GHz"
)

echo ""
echo "[1] Sweeping RX LO frequency..."
echo "  -------------------------------------------------------"
printf "  %-12s | %-15s | %-10s | %s\n" "Target" "Readback" "Error" "Status"
echo "  -------------------------------------------------------"

for entry in "${FREQS[@]}"; do
    FREQ=$(echo "$entry" | awk '{print $1}')
    LABEL=$(echo "$entry" | awk '{print $2}')

    # Set RX LO
    echo "$FREQ" > "$PHY_DEV/out_altvoltage0_RX_LO_frequency" 2>/dev/null
    RESULT=$?

    if [ $RESULT -ne 0 ]; then
        printf "  %-12s | %-15s | %-10s | %s\n" "$LABEL" "WRITE_FAIL" "-" "FAIL"
        ((LOCK_FAIL++))
        continue
    fi

    # Small delay for PLL to lock
    sleep 0.1

    # Read back
    READBACK=$(cat "$PHY_DEV/out_altvoltage0_RX_LO_frequency" 2>/dev/null)

    if [ -z "$READBACK" ]; then
        printf "  %-12s | %-15s | %-10s | %s\n" "$LABEL" "READ_FAIL" "-" "FAIL"
        ((LOCK_FAIL++))
        continue
    fi

    # Calculate error
    if [ "$READBACK" -gt "$FREQ" ] 2>/dev/null; then
        ERROR=$((READBACK - FREQ))
    else
        ERROR=$((FREQ - READBACK))
    fi

    # Tolerance: 1 kHz
    if [ "$ERROR" -le 1000 ]; then
        STATUS="OK"
        ((LOCK_PASS++))
    else
        STATUS="DRIFT"
        ((LOCK_PASS++))  # Still counts as locked if readback works
    fi

    # Format readback for display
    if [ "$READBACK" -ge 1000000000 ]; then
        RB_DISP=$(echo "scale=3; $READBACK / 1000000000" | bc 2>/dev/null || echo "$READBACK")
        RB_DISP="${RB_DISP} GHz"
    else
        RB_DISP=$(echo "scale=1; $READBACK / 1000000" | bc 2>/dev/null || echo "$READBACK")
        RB_DISP="${RB_DISP} MHz"
    fi

    ERROR_KHZ=$(echo "scale=1; $ERROR / 1000" | bc 2>/dev/null || echo "$ERROR")

    printf "  %-12s | %-15s | %-10s | %s\n" "$LABEL" "$RB_DISP" "${ERROR_KHZ}kHz" "$STATUS"
done

echo "  -------------------------------------------------------"
echo "  RX LO: $LOCK_PASS locked, $LOCK_FAIL failed"
echo ""

# -----------------------------------------------------------
# TX LO sweep
# -----------------------------------------------------------
TX_LOCK_PASS=0
TX_LOCK_FAIL=0

echo "[2] Sweeping TX LO frequency..."
echo "  -------------------------------------------------------"
printf "  %-12s | %-15s | %-10s | %s\n" "Target" "Readback" "Error" "Status"
echo "  -------------------------------------------------------"

for entry in "${FREQS[@]}"; do
    FREQ=$(echo "$entry" | awk '{print $1}')
    LABEL=$(echo "$entry" | awk '{print $2}')

    # Set TX LO
    echo "$FREQ" > "$PHY_DEV/out_altvoltage1_TX_LO_frequency" 2>/dev/null
    RESULT=$?

    if [ $RESULT -ne 0 ]; then
        printf "  %-12s | %-15s | %-10s | %s\n" "$LABEL" "WRITE_FAIL" "-" "FAIL"
        ((TX_LOCK_FAIL++))
        continue
    fi

    sleep 0.1

    READBACK=$(cat "$PHY_DEV/out_altvoltage1_TX_LO_frequency" 2>/dev/null)

    if [ -z "$READBACK" ]; then
        printf "  %-12s | %-15s | %-10s | %s\n" "$LABEL" "READ_FAIL" "-" "FAIL"
        ((TX_LOCK_FAIL++))
        continue
    fi

    if [ "$READBACK" -gt "$FREQ" ] 2>/dev/null; then
        ERROR=$((READBACK - FREQ))
    else
        ERROR=$((FREQ - READBACK))
    fi

    if [ "$ERROR" -le 1000 ]; then
        STATUS="OK"
    else
        STATUS="DRIFT"
    fi
    ((TX_LOCK_PASS++))

    if [ "$READBACK" -ge 1000000000 ]; then
        RB_DISP=$(echo "scale=3; $READBACK / 1000000000" | bc 2>/dev/null || echo "$READBACK")
        RB_DISP="${RB_DISP} GHz"
    else
        RB_DISP=$(echo "scale=1; $READBACK / 1000000" | bc 2>/dev/null || echo "$READBACK")
        RB_DISP="${RB_DISP} MHz"
    fi

    ERROR_KHZ=$(echo "scale=1; $ERROR / 1000" | bc 2>/dev/null || echo "$ERROR")

    printf "  %-12s | %-15s | %-10s | %s\n" "$LABEL" "$RB_DISP" "${ERROR_KHZ}kHz" "$STATUS"
done

echo "  -------------------------------------------------------"
echo "  TX LO: $TX_LOCK_PASS locked, $TX_LOCK_FAIL failed"

# -----------------------------------------------------------
# 3. Restore default frequency
# -----------------------------------------------------------
echo ""
echo "[3] Restoring 2.4 GHz..."
echo "2400000000" > "$PHY_DEV/out_altvoltage0_RX_LO_frequency" 2>/dev/null
echo "2400000000" > "$PHY_DEV/out_altvoltage1_TX_LO_frequency" 2>/dev/null
echo "  Done."

# -----------------------------------------------------------
# Summary
# -----------------------------------------------------------
TOTAL_PASS=$((LOCK_PASS + TX_LOCK_PASS))
TOTAL_FAIL=$((LOCK_FAIL + TX_LOCK_FAIL))

echo ""
echo "============================================"
echo "  TEST 08 RESULT: $TOTAL_PASS locked, $TOTAL_FAIL failed"
if [ $TOTAL_FAIL -eq 0 ]; then
    echo "  STATUS: PASS"
    echo "  AD9361 PLL locks across full 70 MHz - 6 GHz range"
else
    echo "  STATUS: FAIL"
    echo "  Some frequencies failed to lock"
fi
echo "============================================"

[ $TOTAL_FAIL -eq 0 ] && exit 0 || exit 1

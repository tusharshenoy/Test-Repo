#!/usr/bin/env python3
"""
test_11_ofdm_tx_rx_diag.py — OFDM TX/RX Diagnostic
Checks each stage of the OFDM chain to find where the signal breaks.

Stage 1: Is DAC DMA running? (devmem check)
Stage 2: Is OFDM TX producing output? (capture ADC while TX active)
Stage 3: Is OFDM_Rx time-synchronized? (check DMA FIFO activity)
Stage 4: Is dec_valid_out asserting? (check OFDM RX DMA counters)
"""

import sys
import time
import subprocess
import numpy as np

try:
    import iio
except ImportError:
    print("[FAIL] pylibiio not installed")
    sys.exit(1)

# Config
SAMPLE_RATE  = 30720000
CENTER_FREQ  = 2400000000
RF_BW        = 20000000
TX_ATTEN     = -10.0
RX_GAIN      = 60.0
TX_SAMPLES   = 32768
RX_CAPTURE   = 16384

DAC_DMA_BASE     = 0x7C420000
OFDM_RX_DMA_BASE = 0x7C440000


def devmem_read(addr):
    try:
        r = subprocess.run(["devmem", f"0x{addr:08X}", "32"],
                           capture_output=True, text=True, timeout=5)
        if r.returncode == 0:
            return int(r.stdout.strip(), 16)
    except:
        pass
    return None


def main():
    print("=" * 60)
    print("  OFDM TX/RX Diagnostic")
    print("=" * 60)

    ctx = iio.Context()
    phy = rx_dev = tx_dev = None
    for dev in ctx.devices:
        if dev.name == "ad9361-phy":
            phy = dev
        elif dev.name == "cf-ad9361-lpc":
            rx_dev = dev
        elif dev.name == "cf-ad9361-dds-core-lpc":
            tx_dev = dev

    if not all([phy, rx_dev, tx_dev]):
        print("[FAIL] IIO devices not found")
        return

    # Configure AD9361
    print("\n--- Configuring AD9361 ---")
    phy.find_channel("voltage0", False).attrs["sampling_frequency"].value = str(SAMPLE_RATE)
    phy.find_channel("altvoltage0", True).attrs["frequency"].value = str(CENTER_FREQ)
    phy.find_channel("altvoltage1", True).attrs["frequency"].value = str(CENTER_FREQ)
    phy.find_channel("voltage0", False).attrs["rf_bandwidth"].value = str(RF_BW)
    phy.find_channel("voltage0", True).attrs["rf_bandwidth"].value = str(RF_BW)
    phy.find_channel("voltage0", True).attrs["hardwaregain"].value = str(TX_ATTEN)
    phy.find_channel("voltage0", False).attrs["gain_control_mode"].value = "manual"
    phy.find_channel("voltage0", False).attrs["hardwaregain"].value = str(RX_GAIN)
    print("  AD9361 configured")

    # Disable DDS
    for ch_id in range(8):
        ch = tx_dev.find_channel(f"altvoltage{ch_id}", True)
        if ch:
            ch.attrs["scale"].value = "0"
    print("  DDS disabled")

    # ============================================================
    # STAGE 1: Baseline — capture ADC with NO TX (noise floor)
    # ============================================================
    print("\n--- Stage 1: Baseline (no TX) ---")
    rx_i = rx_dev.find_channel("voltage0", False)
    rx_q = rx_dev.find_channel("voltage1", False)
    rx_i.enabled = True
    rx_q.enabled = True

    rx_buf = iio.Buffer(rx_dev, RX_CAPTURE, False)
    # Flush a few buffers
    for _ in range(3):
        rx_buf.refill()

    rx_buf.refill()
    raw = rx_buf.read()
    data = np.frombuffer(raw, dtype=np.int16)
    I_baseline = data[0::2].astype(np.float64)
    Q_baseline = data[1::2].astype(np.float64)
    rms_baseline = np.sqrt(np.mean(I_baseline**2 + Q_baseline**2))
    print(f"  Baseline RMS (no TX): {rms_baseline:.1f}")
    print(f"  I: std={np.std(I_baseline):.1f}, peak={np.max(np.abs(I_baseline)):.0f}")
    del rx_buf

    # ============================================================
    # STAGE 2: Start OFDM TX and capture ADC
    # ============================================================
    print("\n--- Stage 2: Start OFDM TX, capture ADC ---")

    # Read DAC DMA status BEFORE
    dac_status_before = devmem_read(DAC_DMA_BASE + 0x428)
    dac_xfer_before = devmem_read(DAC_DMA_BASE + 0x404)
    print(f"  DAC DMA before TX: STATUS=0x{dac_status_before:08X}, XFER_ID=0x{dac_xfer_before:08X}" if dac_status_before is not None else "  DAC DMA: read failed")

    # Push TX data via IIO (this feeds DAC DMA → PS_PL_FIFO → TX_Top → OFDM_Tx)
    tx_i_ch = tx_dev.find_channel("voltage0", True)
    tx_q_ch = tx_dev.find_channel("voltage1", True)
    tx_i_ch.enabled = True
    tx_q_ch.enabled = True

    tx_buf = iio.Buffer(tx_dev, TX_SAMPLES, True)  # cyclic

    # Generate simple ramp payload
    payload = np.zeros(TX_SAMPLES * 2, dtype=np.int16)
    for i in range(0, len(payload), 2):
        payload[i] = np.int16((i // 2) & 0x7FFF)      # I = ramp
        payload[i + 1] = np.int16(((i // 2) + 100) & 0x7FFF)  # Q = offset ramp

    tx_buf.write(bytearray(payload.tobytes()))
    tx_buf.push()
    print("  TX buffer pushed (cyclic)")

    # Wait for OFDM TX to start producing output
    time.sleep(2.0)

    # Read DAC DMA status AFTER
    dac_status_after = devmem_read(DAC_DMA_BASE + 0x428)
    dac_xfer_after = devmem_read(DAC_DMA_BASE + 0x404)
    print(f"  DAC DMA after TX:  STATUS=0x{dac_status_after:08X}, XFER_ID=0x{dac_xfer_after:08X}" if dac_status_after is not None else "  DAC DMA: read failed")

    # Capture ADC while OFDM TX is active
    rx_buf2 = iio.Buffer(rx_dev, RX_CAPTURE, False)
    for _ in range(3):
        rx_buf2.refill()

    rx_buf2.refill()
    raw2 = rx_buf2.read()
    data2 = np.frombuffer(raw2, dtype=np.int16)
    I_ofdm = data2[0::2].astype(np.float64)
    Q_ofdm = data2[1::2].astype(np.float64)
    rms_ofdm = np.sqrt(np.mean(I_ofdm**2 + Q_ofdm**2))
    del rx_buf2

    print(f"  ADC RMS with OFDM TX: {rms_ofdm:.1f}")
    print(f"  I: std={np.std(I_ofdm):.1f}, peak={np.max(np.abs(I_ofdm)):.0f}")
    print(f"  Q: std={np.std(Q_ofdm):.1f}, peak={np.max(np.abs(Q_ofdm)):.0f}")

    rms_increase = rms_ofdm / max(rms_baseline, 1.0)
    print(f"  RMS increase over baseline: {rms_increase:.1f}x ({20*np.log10(max(rms_increase,0.001)):.1f} dB)")

    if rms_increase > 3.0:
        print("  [PASS] OFDM TX IS producing output (ADC sees signal)")
        ofdm_tx_active = True
    elif rms_increase > 1.5:
        print("  [WARN] Weak OFDM TX signal detected")
        ofdm_tx_active = True
    else:
        print("  [FAIL] NO OFDM TX output detected — ADC sees only noise")
        print("         The OFDM TX chain is NOT producing modulated output.")
        print("         Possible causes:")
        print("           - PS_PL_FIFO not receiving data from DAC DMA")
        print("           - TX_Top not producing txValid")
        print("           - din_data_0_0/1_0 not connected to DAC in BD")
        ofdm_tx_active = False

    # FFT analysis
    print("\n--- Stage 2b: Spectrum analysis ---")
    complex_sig = I_ofdm + 1j * Q_ofdm
    fft_out = np.fft.fftshift(np.fft.fft(complex_sig * np.hanning(len(complex_sig))))
    fft_mag = 20 * np.log10(np.abs(fft_out) + 1e-12)
    freqs = np.fft.fftshift(np.fft.fftfreq(len(complex_sig), 1.0 / SAMPLE_RATE)) / 1e6

    # Check spectral occupancy (OFDM should have ~20 MHz bandwidth)
    center_idx = len(fft_mag) // 2
    bw_bins = int(len(fft_mag) * 10e6 / SAMPLE_RATE)  # +/- 10 MHz
    in_band = fft_mag[center_idx - bw_bins:center_idx + bw_bins]
    out_band_lo = fft_mag[:center_idx - bw_bins - 100]
    out_band_hi = fft_mag[center_idx + bw_bins + 100:]

    if len(out_band_lo) > 0 and len(out_band_hi) > 0:
        in_band_power = np.mean(in_band)
        out_band_power = np.mean(np.concatenate([out_band_lo, out_band_hi]))
        print(f"  In-band power (+-10 MHz):  {in_band_power:.1f} dB")
        print(f"  Out-of-band power:         {out_band_power:.1f} dB")
        print(f"  Spectral contrast:         {in_band_power - out_band_power:.1f} dB")

        if in_band_power - out_band_power > 10:
            print("  [PASS] OFDM-like wideband spectrum detected")
        else:
            print("  [INFO] No clear wideband signal — may be narrowband or noise")

    # Peak frequency
    peak_idx = np.argmax(fft_mag)
    peak_freq = freqs[peak_idx]
    peak_power = fft_mag[peak_idx]
    print(f"  Peak: {peak_freq:.3f} MHz at {peak_power:.1f} dB")

    # Save spectrum for offline analysis
    np.savez("ofdm_diag_capture.npz",
             I_baseline=I_baseline, Q_baseline=Q_baseline,
             I_ofdm=I_ofdm, Q_ofdm=Q_ofdm,
             fft_mag=fft_mag, freqs=freqs)
    print("  Saved: ofdm_diag_capture.npz")

    # ============================================================
    # STAGE 3: Check OFDM RX DMA status
    # ============================================================
    print("\n--- Stage 3: OFDM RX DMA status ---")

    ver = devmem_read(OFDM_RX_DMA_BASE + 0x000)
    ctrl = devmem_read(OFDM_RX_DMA_BASE + 0x400)
    status = devmem_read(OFDM_RX_DMA_BASE + 0x428)
    xfer_id = devmem_read(OFDM_RX_DMA_BASE + 0x404)
    irq_pend = devmem_read(OFDM_RX_DMA_BASE + 0x084)
    cur_dest = devmem_read(OFDM_RX_DMA_BASE + 0x434)
    partial = devmem_read(OFDM_RX_DMA_BASE + 0x44C)
    dbg0 = devmem_read(OFDM_RX_DMA_BASE + 0x43C)

    print(f"  VERSION:      0x{ver:08X}" if ver else "  VERSION:      read failed")
    print(f"  CTRL:         0x{ctrl:08X}" if ctrl else "  CTRL:         read failed")
    print(f"  STATUS:       0x{status:08X}" if status is not None else "  STATUS:       read failed")
    print(f"  XFER_ID:      0x{xfer_id:08X}" if xfer_id is not None else "  XFER_ID:      read failed")
    print(f"  IRQ_PENDING:  0x{irq_pend:08X}" if irq_pend is not None else "  IRQ_PENDING:  read failed")
    print(f"  CURRENT_DEST: 0x{cur_dest:08X}" if cur_dest is not None else "  CURRENT_DEST: read failed")
    print(f"  PARTIAL_LEN:  0x{partial:08X}" if partial is not None else "  PARTIAL_LEN:  read failed")
    print(f"  DBG_STATUS:   0x{dbg0:08X}" if dbg0 is not None else "  DBG_STATUS:   read failed")

    if partial is not None and partial > 0:
        print(f"  [INFO] Partial transfer: {partial} bytes received")
    elif status == 0 and irq_pend == 0:
        print("  [DIAG] DMA idle — fifo_wr_en NEVER asserted")
        print("         dec_valid_out from RX_Top is stuck at 0")
        print("         OFDM_Rx never synchronized / decoded a frame")

    # ============================================================
    # STAGE 4: Summary & recommendations
    # ============================================================
    print("\n" + "=" * 60)
    print("  DIAGNOSTIC SUMMARY")
    print("=" * 60)
    print(f"  RF loopback path:     WORKING (test_03/05 passed)")
    print(f"  ADC baseline RMS:     {rms_baseline:.1f}")
    print(f"  ADC with OFDM TX:     {rms_ofdm:.1f} ({rms_increase:.1f}x baseline)")

    if not ofdm_tx_active:
        print(f"\n  DIAGNOSIS: OFDM TX chain is NOT producing output.")
        print(f"  The DAC DMA data goes to PS_PL_FIFO but TX_Top/OFDM_Tx")
        print(f"  may not be generating txValid. Need ILA probes on:")
        print(f"    - m_axis_valid_0 (DAC DMA output valid)")
        print(f"    - wr_en_reg (PS_PL_FIFO read valid)")
        print(f"    - txValid (TX_Top output)")
        print(f"    - txData_re/txData_im (OFDM modulated IQ)")
    else:
        print(f"\n  DIAGNOSIS: OFDM TX is producing output, but OFDM_Rx")
        print(f"  never synchronizes (dec_valid_out stays 0).")
        print(f"  The OFDM_Rx (MATLAB HDL Coder) needs to:")
        print(f"    1. Detect preamble (L-STF autocorrelation)")
        print(f"    2. Estimate frequency offset")
        print(f"    3. Decode signal field / header")
        print(f"  Need ILA probes on:")
        print(f"    - diagBus_timeSynchronised")
        print(f"    - diagBus_headerCaptured")
        print(f"    - diagBus_frameDecoded")
        print(f"    - diagBus_frameError")
        print(f"    - dataBitsValid (OFDM_Rx validOut)")
    print("=" * 60)


if __name__ == "__main__":
    main()

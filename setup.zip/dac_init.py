#!/usr/bin/env python3
"""
dac_init.py — DAC DMA mode initialization utility

Forces dac_data_sel = 2 (DMA_data mode) on all 4 DAC channels.
Can be used standalone or imported by test scripts.

Standalone:
    python3 dac_init.py              # one-shot force
    python3 dac_init.py --watch      # continuous background force
    python3 dac_init.py --verify     # read-only check

As a module:
    from dac_init import force_dac_dma_mode, DacSelForcer
    force_dac_dma_mode()             # one-shot
    forcer = DacSelForcer()          # continuous
    forcer.start()
    ...
    forcer.stop()
"""

import subprocess
import sys
import threading
import time

# =====================================================================
# Hardware Addresses
# =====================================================================
AXI_AD9361_BASE = 0x79020000

DAC_CHAN_BASES = {
    "I0": AXI_AD9361_BASE + 0x0400,
    "Q0": AXI_AD9361_BASE + 0x0440,
    "I1": AXI_AD9361_BASE + 0x0480,
    "Q1": AXI_AD9361_BASE + 0x04C0,
}
DAC_DATA_SEL_OFF = 0x0018

DATA_SEL_NAMES = {
    0: "DDS_tone", 1: "SED_pattern", 2: "DMA_data",
    8: "PN7", 9: "zero_output", 10: "PN15",
    11: "PRBS_seq", 12: "input_sel",
}

# Computed register addresses
DAC_DATA_SEL_ADDRS = {
    ch: base + DAC_DATA_SEL_OFF for ch, base in DAC_CHAN_BASES.items()
}


# =====================================================================
# Low-level devmem helpers
# =====================================================================
def devmem_read(addr):
    """Read a 32-bit register via devmem. Returns int or None on failure."""
    try:
        r = subprocess.run(
            ["devmem", f"0x{addr:08X}", "32"],
            capture_output=True, text=True, timeout=5,
        )
        if r.returncode == 0:
            return int(r.stdout.strip(), 16)
    except Exception:
        pass
    return None


def devmem_write(addr, val):
    """Write a 32-bit register via devmem. Returns True on success."""
    try:
        r = subprocess.run(
            ["devmem", f"0x{addr:08X}", "32", f"0x{val:08X}"],
            capture_output=True, text=True, timeout=5,
        )
        return r.returncode == 0
    except Exception:
        pass
    return False


# =====================================================================
# Public API
# =====================================================================
def read_dac_data_sel():
    """Read dac_data_sel for all channels. Returns dict {ch: (value, name)}."""
    results = {}
    for ch, addr in DAC_DATA_SEL_ADDRS.items():
        val = devmem_read(addr)
        name = DATA_SEL_NAMES.get(val, "unknown") if val is not None else "read_error"
        results[ch] = (val, name)
    return results


def force_dac_dma_mode(verbose=True):
    """Force all DAC channels to DMA mode (2). Returns True if all succeeded."""
    if verbose:
        print("[DAC] Forcing dac_data_sel = 2 (DMA_data) on all channels...")

    all_ok = True
    for ch, addr in DAC_DATA_SEL_ADDRS.items():
        ok = devmem_write(addr, 2)
        if verbose:
            if ok:
                readback = devmem_read(addr)
                sel_name = DATA_SEL_NAMES.get(readback, "unknown")
                status = "OK" if readback == 2 else f"VERIFY FAIL (got {readback})"
                print(f"  DAC {ch} [0x{addr:08X}]: {status} ({sel_name})")
            else:
                print(f"  DAC {ch} [0x{addr:08X}]: WRITE FAILED")
                all_ok = False
    return all_ok


def verify_dac_dma_mode(verbose=True):
    """Check all DAC channels are in DMA mode. Returns True if all are mode 2."""
    results = read_dac_data_sel()
    all_ok = True
    for ch in ["I0", "Q0", "I1", "Q1"]:
        val, name = results[ch]
        ok = val == 2
        if not ok:
            all_ok = False
        if verbose:
            addr = DAC_DATA_SEL_ADDRS[ch]
            status = "OK" if ok else "WRONG"
            print(f"  DAC {ch} [0x{addr:08X}]: {val} ({name}) [{status}]")
    return all_ok


class DacSelForcer:
    """Background thread that continuously forces dac_data_sel = 2 (DMA mode).

    Usage:
        forcer = DacSelForcer()
        forcer.start()
        # ... run test ...
        forcer.stop()
    """

    def __init__(self, interval=0.005):
        self.interval = interval
        self._stop = threading.Event()
        self._thread = None
        self.force_count = 0
        self.revert_count = 0

    def start(self):
        if self._thread and self._thread.is_alive():
            return
        self._stop.clear()
        self.force_count = 0
        self.revert_count = 0
        # Do initial force
        force_dac_dma_mode(verbose=False)
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()
        print(f"[DAC] Background forcer started (interval={self.interval*1000:.0f}ms)")

    def _run(self):
        while not self._stop.is_set():
            for addr in DAC_DATA_SEL_ADDRS.values():
                val = devmem_read(addr)
                if val is not None and val != 2:
                    devmem_write(addr, 2)
                    self.revert_count += 1
            self.force_count += 1
            self._stop.wait(self.interval)

    def stop(self):
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=2)
        print(f"[DAC] Forcer stopped. Checks: {self.force_count}, reverts: {self.revert_count}")

    def __enter__(self):
        self.start()
        return self

    def __exit__(self, *args):
        self.stop()


# =====================================================================
# CLI entry point
# =====================================================================
if __name__ == "__main__":
    mode = sys.argv[1] if len(sys.argv) > 1 else None

    if mode == "--verify":
        print("============================================")
        print("  DAC data_sel — Verify")
        print("============================================")
        ok = verify_dac_dma_mode()
        sys.exit(0 if ok else 1)

    elif mode == "--watch":
        print("============================================")
        print("  DAC data_sel — Watch mode (Ctrl+C to stop)")
        print("============================================")
        forcer = DacSelForcer(interval=0.1)
        forcer.start()
        try:
            while True:
                time.sleep(10)
                print(f"[WATCH] Checks: {forcer.force_count}, reverts: {forcer.revert_count}")
        except KeyboardInterrupt:
            forcer.stop()
            print("[STOP] Done.")

    else:
        print("============================================")
        print("  DAC data_sel -> DMA mode (2)")
        print("============================================")
        print("[1/2] Forcing...")
        force_dac_dma_mode()
        print("[2/2] Verifying...")
        ok = verify_dac_dma_mode()
        if ok:
            print("[OK] All DAC channels set to DMA mode.")
        else:
            print("[WARN] Some channels not in DMA mode. Try: python3 dac_init.py --watch")
        print("============================================")
        sys.exit(0 if ok else 1)

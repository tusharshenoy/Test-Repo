#!/bin/bash
# test_01_iio_check.sh — Verify AD9361 IIO subsystem is alive
# No RF connections needed

echo "============================================"
echo "  TEST 01: IIO Subsystem Check"
echo "============================================"

PASS=0
FAIL=0
WARN=0

pass() { echo "  [PASS] $1"; ((PASS++)); }
fail() { echo "  [FAIL] $1"; ((FAIL++)); }
warn() { echo "  [WARN] $1"; ((WARN++)); }

# -----------------------------------------------------------
# 1. Check IIO devices in sysfs
# -----------------------------------------------------------
echo ""
echo "[1] Checking IIO devices in sysfs..."
IIO_DIR="/sys/bus/iio/devices"

if [ ! -d "$IIO_DIR" ]; then
    fail "IIO sysfs directory not found ($IIO_DIR)"
    echo "  FPGA bitstream may not be loaded or IIO subsystem not enabled."
    echo ""
    echo "============================================"
    echo "  RESULT: FAIL ($FAIL failures)"
    echo "============================================"
    exit 1
fi

# Find device names
DEVICES=""
for dev in "$IIO_DIR"/iio:device*; do
    if [ -f "$dev/name" ]; then
        NAME=$(cat "$dev/name")
        DEV_ID=$(basename "$dev")
        DEVICES="$DEVICES $NAME"
        echo "  Found: $DEV_ID = $NAME"
    fi
done

# -----------------------------------------------------------
# 2. Check required IIO devices
# -----------------------------------------------------------
echo ""
echo "[2] Checking required IIO devices..."

# ad9361-phy — RF transceiver control
if echo "$DEVICES" | grep -q "ad9361-phy"; then
    pass "ad9361-phy (RF transceiver) found"
else
    fail "ad9361-phy NOT found — AD9361 SPI/driver issue"
fi

# cf-ad9361-lpc — ADC/RX capture
if echo "$DEVICES" | grep -q "cf-ad9361-lpc"; then
    pass "cf-ad9361-lpc (ADC/RX) found"
else
    fail "cf-ad9361-lpc NOT found — RX DMA path issue"
fi

# cf-ad9361-dds-core-lpc — DAC/TX
if echo "$DEVICES" | grep -q "cf-ad9361-dds-core-lpc"; then
    pass "cf-ad9361-dds-core-lpc (DAC/TX) found"
else
    fail "cf-ad9361-dds-core-lpc NOT found — TX DMA path issue"
fi

# -----------------------------------------------------------
# 3. Find device paths for later use
# -----------------------------------------------------------
PHY_DEV=""
RX_DEV=""
TX_DEV=""

for dev in "$IIO_DIR"/iio:device*; do
    [ ! -f "$dev/name" ] && continue
    NAME=$(cat "$dev/name")
    case "$NAME" in
        ad9361-phy) PHY_DEV="$dev" ;;
        cf-ad9361-lpc) RX_DEV="$dev" ;;
        cf-ad9361-dds-core-lpc) TX_DEV="$dev" ;;
    esac
done

# -----------------------------------------------------------
# 4. Read AD9361 temperature
# -----------------------------------------------------------
echo ""
echo "[3] Reading AD9361 temperature..."
if [ -n "$PHY_DEV" ]; then
    TEMP_RAW=$(cat "$PHY_DEV/in_temp0_input" 2>/dev/null)
    if [ -n "$TEMP_RAW" ]; then
        # AD9361 temp is in millidegrees C
        TEMP_C=$(echo "scale=1; $TEMP_RAW / 1000" | bc 2>/dev/null || echo "$TEMP_RAW mdeg")
        echo "  Temperature: ${TEMP_C} C"
        pass "Temperature sensor readable"
    else
        warn "Could not read temperature (in_temp0_input)"
    fi
else
    warn "ad9361-phy not available, skipping temperature"
fi

# -----------------------------------------------------------
# 5. Check RX channels
# -----------------------------------------------------------
echo ""
echo "[4] Checking RX channels..."
if [ -n "$RX_DEV" ]; then
    RX_CHANNELS=$(ls "$RX_DEV" 2>/dev/null | grep "in_voltage" | grep -v "scale\|offset\|raw" | sort -u | head -10)
    if [ -n "$RX_CHANNELS" ]; then
        echo "  RX channels found:"
        for ch in $RX_CHANNELS; do
            echo "    - $ch"
        done
        pass "RX channels available"
    else
        # Try scanning attributes
        RX_SCAN=$(ls "$RX_DEV/scan_elements" 2>/dev/null | head -10)
        if [ -n "$RX_SCAN" ]; then
            echo "  RX scan elements:"
            for elem in $RX_SCAN; do
                echo "    - $elem"
            done
            pass "RX scan elements available"
        else
            fail "No RX channels found"
        fi
    fi
else
    fail "cf-ad9361-lpc not available"
fi

# -----------------------------------------------------------
# 6. Check TX channels
# -----------------------------------------------------------
echo ""
echo "[5] Checking TX channels..."
if [ -n "$TX_DEV" ]; then
    TX_CHANNELS=$(ls "$TX_DEV" 2>/dev/null | grep "out_altvoltage" | grep -v "scale\|phase" | sort -u | head -10)
    if [ -n "$TX_CHANNELS" ]; then
        echo "  TX DDS channels found:"
        for ch in $TX_CHANNELS; do
            echo "    - $ch"
        done
        pass "TX DDS channels available"
    else
        TX_SCAN=$(ls "$TX_DEV/scan_elements" 2>/dev/null | head -10)
        if [ -n "$TX_SCAN" ]; then
            echo "  TX scan elements:"
            for elem in $TX_SCAN; do
                echo "    - $elem"
            done
            pass "TX scan elements available"
        else
            warn "No TX channels enumerated (may still work via buffer)"
        fi
    fi
else
    fail "cf-ad9361-dds-core-lpc not available"
fi

# -----------------------------------------------------------
# 7. Read RSSI (if available)
# -----------------------------------------------------------
echo ""
echo "[6] Reading RSSI..."
if [ -n "$PHY_DEV" ]; then
    for rssi_file in "$PHY_DEV"/in_voltage*_rssi; do
        if [ -f "$rssi_file" ]; then
            RSSI_VAL=$(cat "$rssi_file" 2>/dev/null)
            RSSI_NAME=$(basename "$rssi_file")
            echo "  $RSSI_NAME = $RSSI_VAL dB"
        fi
    done
    pass "RSSI readable"
else
    warn "ad9361-phy not available, skipping RSSI"
fi

# -----------------------------------------------------------
# 8. Check iio_info output (if available)
# -----------------------------------------------------------
echo ""
echo "[7] Running iio_info (summary)..."
if command -v iio_info &>/dev/null; then
    NDEV=$(iio_info 2>/dev/null | grep -c "iio:device" || echo "0")
    echo "  iio_info reports $NDEV device(s)"
    pass "iio_info works"
else
    warn "iio_info command not found (install libiio-utils)"
fi

# -----------------------------------------------------------
# Summary
# -----------------------------------------------------------
echo ""
echo "============================================"
echo "  TEST 01 RESULT: $PASS passed, $FAIL failed, $WARN warnings"
if [ $FAIL -eq 0 ]; then
    echo "  STATUS: PASS"
    echo "============================================"
    exit 0
else
    echo "  STATUS: FAIL"
    echo "============================================"
    exit 1
fi

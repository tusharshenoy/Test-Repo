#!/usr/bin/env python3
"""
test_07_ofdm_loopback.py — End-to-end OFDM loopback with diagnostics
Requires: TX1A → RX1A (direct SMA cable loopback)

Tests the full OFDM TX chain:
  PS → DAC DMA → PS_PL_FIFO (64→16b) → TX_Top (HDLC) → OFDM_Tx
    → DAC FIFO → AD9361 DAC → RF → RX → ADC DMA → PS

Includes fallback analysis using DDS tone if OFDM TX chain
doesn't produce output.
"""

import sys
import time
import subprocess
import numpy as np

try:
    import iio
except ImportError:
    print("[FAIL] pylibiio not installed. Run: pip3 install pylibiio")
    sys.exit(1)

# -------------------------------------------------------
# Configuration
# -------------------------------------------------------
SAMPLE_RATE  = 30720000     # 30.72 MSPS
CENTER_FREQ  = 2400000000   # 2.4 GHz
RF_BW        = 20000000     # 20 MHz
TX_ATTEN     = -10.0        # dB (output ~-3 dBm, safe below AD9361 +2.5 dBm max RX input)
RX_GAIN      = 60.0         # dB (high gain needed for OFDM signal detection)
NUM_SAMPLES  = 32768        # per buffer
NUM_CAPTURE  = 15           # RX buffers
SKIP_BUFFERS = 3
FFT_SIZE     = 128          # OFDM FFT size from RTL
CP_LEN       = 32           # estimated cyclic prefix

# DMA register base
DAC_DMA_BASE = 0x7C420000


def devmem_read(addr):
    """Read 32-bit register via devmem."""
    try:
        result = subprocess.run(
            ["devmem", f"0x{addr:08X}", "32"],
            capture_output=True, text=True, timeout=5
        )
        if result.returncode == 0:
            return int(result.stdout.strip(), 16)
    except Exception:
        pass
    return None


def find_devices(ctx):
    phy = rx_dev = tx_dev = None
    for dev in ctx.devices:
        if dev.name == "ad9361-phy":
            phy = dev
        elif dev.name == "cf-ad9361-lpc":
            rx_dev = dev
        elif dev.name == "cf-ad9361-dds-core-lpc":
            tx_dev = dev
    return phy, rx_dev, tx_dev


def configure_ad9361(phy):
    phy.find_channel("voltage0", is_output=False).attrs["sampling_frequency"].value = str(SAMPLE_RATE)
    phy.find_channel("altvoltage0", is_output=True).attrs["frequency"].value = str(CENTER_FREQ)
    phy.find_channel("altvoltage1", is_output=True).attrs["frequency"].value = str(CENTER_FREQ)
    phy.find_channel("voltage0", is_output=False).attrs["rf_bandwidth"].value = str(RF_BW)
    phy.find_channel("voltage0", is_output=True).attrs["rf_bandwidth"].value = str(RF_BW)
    phy.find_channel("voltage0", is_output=True).attrs["hardwaregain"].value = str(TX_ATTEN)
    phy.find_channel("voltage0", is_output=False).attrs["gain_control_mode"].value = "manual"
    phy.find_channel("voltage0", is_output=False).attrs["hardwaregain"].value = str(RX_GAIN)


def capture_rx(rx_dev, num_samples, num_buffers, skip):
    """Capture RX IQ data."""
    rx_i = rx_dev.find_channel("voltage0", is_output=False)
    rx_q = rx_dev.find_channel("voltage1", is_output=False)
    rx_i.enabled = True
    rx_q.enabled = True
    rx_buf = iio.Buffer(rx_dev, num_samples, False)

    all_i = []
    all_q = []
    for buf_idx in range(num_buffers):
        rx_buf.refill()
        raw = np.frombuffer(rx_buf.read(), dtype=np.int16)
        if buf_idx >= skip:
            all_i.append(raw[0::2].astype(np.float64))
            all_q.append(raw[1::2].astype(np.float64))

    rx_i.enabled = False
    rx_q.enabled = False

    return np.concatenate(all_i), np.concatenate(all_q)


def analyze_spectrum(rx_i, rx_q, sample_rate, fft_len=None):
    """Compute spectral analysis."""
    if fft_len is None:
        fft_len = min(16384, len(rx_i))
    rx_complex = rx_i[:fft_len] + 1j * rx_q[:fft_len]
    window = np.hanning(fft_len)

    fft_vals = np.fft.fftshift(np.fft.fft(rx_complex * window))
    fft_db = 20 * np.log10(np.abs(fft_vals) + 1e-10)
    freqs = np.fft.fftshift(np.fft.fftfreq(fft_len, 1.0/sample_rate))

    noise_floor = np.median(fft_db)
    peak_idx = np.argmax(fft_db)
    peak_freq = freqs[peak_idx]
    peak_db = fft_db[peak_idx]

    # PAPR
    peak_power = np.max(np.abs(rx_complex)**2)
    avg_power = np.mean(np.abs(rx_complex)**2)
    papr = 10 * np.log10(peak_power / (avg_power + 1e-10))

    # Occupied bandwidth
    above_noise = fft_db > (noise_floor + 10)
    occupied_bw = np.sum(above_noise) * (sample_rate / fft_len)

    return {
        'rms': np.sqrt(avg_power),
        'power_db': 10 * np.log10(avg_power + 1e-10),
        'peak_freq': peak_freq,
        'peak_db': peak_db,
        'noise_floor': noise_floor,
        'snr': peak_db - noise_floor,
        'papr': papr,
        'occupied_bw': occupied_bw,
    }


def main():
    print("============================================")
    print("  TEST 07: OFDM End-to-End Loopback")
    print("============================================")
    print("")
    print("[PREREQ] Connect: TX1A → RX1A (direct SMA cable)")
    print("")

    PASS = 0
    FAIL = 0

    # Connect
    try:
        ctx = iio.Context()
    except Exception as e:
        print(f"[FAIL] Cannot create IIO context: {e}")
        return 1

    phy, rx_dev, tx_dev = find_devices(ctx)
    if not all([phy, rx_dev, tx_dev]):
        print("[FAIL] Not all IIO devices found")
        return 1

    # -----------------------------------------------------------
    # 1. Configure AD9361
    # -----------------------------------------------------------
    print("[1] Configuring AD9361...")
    configure_ad9361(phy)
    PASS += 1
    print("  [PASS] AD9361 configured")

    # -----------------------------------------------------------
    # 2. Phase A: DDS reference capture
    # -----------------------------------------------------------
    print("\n[2] Phase A: Capturing DDS reference tone...")
    try:
        ch = tx_dev.find_channel("altvoltage0", is_output=True)
        ch.attrs["frequency"].value = "1000000"
        ch.attrs["scale"].value = "0.5"
        ch.attrs["phase"].value = "0"
        ch = tx_dev.find_channel("altvoltage1", is_output=True)
        ch.attrs["scale"].value = "0"
        ch = tx_dev.find_channel("altvoltage2", is_output=True)
        ch.attrs["frequency"].value = "1000000"
        ch.attrs["scale"].value = "0.5"
        ch.attrs["phase"].value = "90000"
        ch = tx_dev.find_channel("altvoltage3", is_output=True)
        ch.attrs["scale"].value = "0"
    except Exception as e:
        print(f"  DDS setup error: {e}")

    time.sleep(0.5)
    dds_i, dds_q = capture_rx(rx_dev, NUM_SAMPLES, 8, 3)
    dds_stats = analyze_spectrum(dds_i, dds_q, SAMPLE_RATE)
    print(f"  DDS RMS: {dds_stats['rms']:.1f}, SNR: {dds_stats['snr']:.1f} dB")
    print(f"  DDS peak: {dds_stats['peak_freq']/1e6:.3f} MHz")

    if dds_stats['rms'] > 20:
        PASS += 1
        print("  [PASS] RF loopback working (DDS)")
    else:
        FAIL += 1
        print("  [FAIL] RF loopback broken — check cable")
        return 1

    # -----------------------------------------------------------
    # 3. Phase B: Disable DDS, capture baseline
    # -----------------------------------------------------------
    print("\n[3] Phase B: Baseline (no TX)...")
    for ch_id in range(8):
        ch = tx_dev.find_channel(f"altvoltage{ch_id}", is_output=True)
        if ch:
            ch.attrs["scale"].value = "0"

    time.sleep(0.3)
    base_i, base_q = capture_rx(rx_dev, NUM_SAMPLES, 8, 3)
    base_stats = analyze_spectrum(base_i, base_q, SAMPLE_RATE)
    print(f"  Baseline RMS: {base_stats['rms']:.1f}, Power: {base_stats['power_db']:.1f} dB")

    # -----------------------------------------------------------
    # 4. Phase C: Push DMA data and capture
    # -----------------------------------------------------------
    print("\n[4] Phase C: OFDM TX via DMA...")
    try:
        tx_i = tx_dev.find_channel("voltage0", is_output=True)
        tx_q = tx_dev.find_channel("voltage1", is_output=True)
        tx_i.enabled = True
        tx_q.enabled = True

        tx_buf = iio.Buffer(tx_dev, NUM_SAMPLES, True)

        # Generate payload data
        payload = np.zeros(NUM_SAMPLES * 2, dtype=np.int16)
        for i in range(0, len(payload), 2):
            payload[i]     = np.int16(0x5555)
            payload[i + 1] = np.int16(0x3333)

        tx_buf.write(bytearray(payload.tobytes()))
        tx_buf.push()
        print("  TX DMA buffer pushed (cyclic)")
    except Exception as e:
        print(f"  [FAIL] TX DMA error: {e}")
        FAIL += 1

    # Wait for OFDM chain
    print("  Waiting 3s for OFDM TX chain...")
    time.sleep(3)

    # Check DMA status
    dma_ctrl = devmem_read(DAC_DMA_BASE + 0x400)
    dma_stat = devmem_read(DAC_DMA_BASE + 0x428)
    if dma_ctrl is not None:
        print(f"  DMA CTRL=0x{dma_ctrl:08X} STATUS=0x{dma_stat:08X}" if dma_stat else f"  DMA CTRL=0x{dma_ctrl:08X}")

    # Capture RX
    ofdm_i, ofdm_q = capture_rx(rx_dev, NUM_SAMPLES, NUM_CAPTURE, SKIP_BUFFERS)
    ofdm_stats = analyze_spectrum(ofdm_i, ofdm_q, SAMPLE_RATE)

    print(f"  OFDM RMS: {ofdm_stats['rms']:.1f}, Power: {ofdm_stats['power_db']:.1f} dB")
    print(f"  PAPR: {ofdm_stats['papr']:.1f} dB")
    print(f"  Occupied BW: {ofdm_stats['occupied_bw']/1e6:.2f} MHz")
    print(f"  Peak: {ofdm_stats['peak_freq']/1e6:.3f} MHz, SNR: {ofdm_stats['snr']:.1f} dB")

    power_delta = ofdm_stats['power_db'] - base_stats['power_db']
    print(f"\n  Power delta (OFDM vs baseline): {power_delta:+.1f} dB")

    # -----------------------------------------------------------
    # 5. Save capture
    # -----------------------------------------------------------
    output_file = "ofdm_loopback_capture.bin"
    total = len(ofdm_i)
    save_data = np.empty(total * 2, dtype=np.int16)
    save_data[0::2] = ofdm_i.astype(np.int16)
    save_data[1::2] = ofdm_q.astype(np.int16)
    with open(output_file, 'wb') as f:
        f.write(save_data.tobytes())
    print(f"\n[5] Saved capture: {output_file} ({total} samples)")

    # -----------------------------------------------------------
    # 6. Results
    # -----------------------------------------------------------
    print("\n============================================")
    print("  RESULTS SUMMARY:")
    print(f"  {'Signal':20s} {'RMS':>8s} {'Power':>8s} {'SNR':>8s}")
    print(f"  {'─'*20} {'─'*8} {'─'*8} {'─'*8}")
    print(f"  {'DDS (reference)':20s} {dds_stats['rms']:8.1f} {dds_stats['power_db']:7.1f}dB {dds_stats['snr']:7.1f}dB")
    print(f"  {'Baseline (no TX)':20s} {base_stats['rms']:8.1f} {base_stats['power_db']:7.1f}dB {base_stats['snr']:7.1f}dB")
    print(f"  {'OFDM TX (DMA)':20s} {ofdm_stats['rms']:8.1f} {ofdm_stats['power_db']:7.1f}dB {ofdm_stats['snr']:7.1f}dB")
    print("")

    if power_delta >= 6:
        PASS += 1
        print(f"  [PASS] OFDM TX signal detected (+{power_delta:.1f} dB above noise)")

        # Additional OFDM checks
        if ofdm_stats['papr'] > 4:
            PASS += 1
            print(f"  [PASS] PAPR = {ofdm_stats['papr']:.1f} dB (multicarrier)")

        if ofdm_stats['occupied_bw'] > 1e6:
            PASS += 1
            print(f"  [PASS] Wideband: {ofdm_stats['occupied_bw']/1e6:.1f} MHz")
    else:
        FAIL += 1
        print(f"  [FAIL] OFDM TX not producing RF output (+{power_delta:.1f} dB)")
        print("")
        print("  The DDS tone verifies RF path works.")
        print("  The OFDM TX chain (DMA → FIFO → HDLC → OFDM_Tx → DAC)")
        print("  is not producing output. Most likely causes:")
        print("")
        print("  1. OFDM_Tx 'ready' signal stuck low")
        print("     → HDLC cannot read data → no tx_valid → no IQ output")
        print("     → Add ILA probe on txReady in TX_Top")
        print("")
        print("  2. PS_PL_FIFO clock/reset issue")
        print("     → ofdm_top.clk or n_rst not properly connected")
        print("     → Check util_ad9361_divclk_clk_out drives ofdm_top")
        print("")
        print("  3. DAC FIFO ignoring din_valid_in_0_0")
        print("     → txValid from OFDM_Tx may never assert")
        print("     → Probe din_valid_in_0_0 at dac_fifo input")
        print("")
        print("  Recommended debug:")
        print("    vivado > Open Hardware Manager > Add ILA")
        print("    Probe: txReady, txValid, empty, full, m_axis_valid_0")
        print("    Trigger on m_axis_valid_0 rising edge")

    print(f"\n  TEST 07: {PASS} passed, {FAIL} failed")
    status = "PASS" if FAIL == 0 else "FAIL"
    print(f"  STATUS: {status}")
    print("============================================")
    return 0 if FAIL == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
